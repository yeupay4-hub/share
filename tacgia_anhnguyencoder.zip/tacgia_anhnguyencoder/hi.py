import sys
import ast
import importlib.util
import sysconfig

def is_builtin(module_name):
    if module_name in sys.builtin_module_names:
        return True
    spec = importlib.util.find_spec(module_name)
    if spec and spec.origin:
        stdlib = sysconfig.get_paths()["stdlib"]
        return spec.origin.startswith(stdlib)
    return False

def get_imports(filename):
    with open(filename, "r", encoding="utf-8") as f:
        tree = ast.parse(f.read(), filename)

    modules = set()

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                modules.add(alias.name.split(".")[0])
        elif isinstance(node, ast.ImportFrom):
            if node.module:
                modules.add(node.module.split(".")[0])

    return modules

def main():
    if len(sys.argv) != 2:
        print("Usage: python lay.py <file.py>")
        return

    filename = sys.argv[1]
    modules = get_imports(filename)

    external = sorted(m for m in modules if not is_builtin(m))

    print("\n=== Requirements ===")
    for m in external:
        print(m)

if __name__ == "__main__":
    main()