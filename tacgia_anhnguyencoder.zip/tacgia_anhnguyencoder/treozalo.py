# -*- coding: utf-8 -*-
import os
import time
import json
import threading
import base64
import requests
from enum import Enum
from Crypto.Cipher import AES

HEADERS = {
    "User-Agent": "Mozilla/5.0",
    "Accept": "application/json, text/plain, */*",
    "Origin": "https://chat.zalo.me",
    "Referer": "https://chat.zalo.me/",
    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
}

def now():
    return int(time.time() * 1000)

def zalo_encode(params, key):
    key = base64.b64decode(key)
    iv = bytes(16)
    cipher = AES.new(key, AES.MODE_CBC, iv)
    plaintext = json.dumps(params).encode()
    pad_len = AES.block_size - len(plaintext) % AES.block_size
    padded = plaintext + bytes([pad_len] * pad_len)
    return base64.b64encode(cipher.encrypt(padded)).decode()

def zalo_decode(encrypted_data, key):
    key = base64.b64decode(key)
    iv = bytes(16)
    cipher = AES.new(key, AES.MODE_CBC, iv)
    decrypted = cipher.decrypt(base64.b64decode(encrypted_data))
    pad_len = decrypted[-1]
    return decrypted[:-pad_len].decode('utf-8', errors='ignore')

class ThreadType(Enum):
    USER = 1
    GROUP = 2

class ZaloAPI:
    def __init__(self, imei, cookies):
        self.session = requests.Session()
        self.imei = imei
        self.secret_key = None
        self.uid = None
        self.session.headers.update(HEADERS)
        self.session.cookies.update(cookies)
        self.login()

    def login(self):
        url = "https://wpa.chat.zalo.me/api/login/getLoginInfo"
        params = {"imei": self.imei, "type": 30, "client_version": 645, "ts": now()}
        response = self.session.get(url, params=params)

        try:
            data = response.json()
        except Exception:
            raise Exception("❌ Không thể phân tích JSON từ phản hồi!")

        user_data = data.get("data")
        if not isinstance(user_data, dict):
            print("⚠️ Phản hồi không hợp lệ hoặc sai IMEI/Cookie:")
            print(json.dumps(data, indent=2, ensure_ascii=False))
            raise Exception("❌ Không nhận được thông tin người dùng (user_data)")

        self.uid = user_data.get("send2me_id")
        self.secret_key = user_data.get("zpw_enk")
        if not self.secret_key:
            raise Exception("❌ Không lấy được secret_key")

    def fetch_groups(self):
        url = "https://tt-group-wpa.chat.zalo.me/api/group/getlg/v4"
        params = {"zpw_ver": 645, "zpw_type": 30}
        response = self.session.get(url, params=params)
        data = response.json()
        decoded = zalo_decode(data["data"], self.secret_key)
        parsed = json.loads(decoded)
        grid_map = parsed.get("data", {}).get("gridVerMap", {})
        groups = []
        for group_id in sorted(grid_map.keys(), key=lambda x: int(x)):
            info = self.fetch_group_info(group_id)
            groups.append({
                "id": group_id,
                "name": info["name"],
                "members": info["totalMember"]
            })
        return groups

    def fetch_group_info(self, group_id):
        url = "https://tt-group-wpa.chat.zalo.me/api/group/getmg-v2"
        params = {"zpw_ver": 645, "zpw_type": 30}
        encoded = zalo_encode({"gridVerMap": json.dumps({str(group_id): 0})}, self.secret_key)
        response = self.session.post(url, params=params, data={"params": encoded})
        result = response.json()
        decoded = zalo_decode(result["data"], self.secret_key)
        parsed = json.loads(decoded)
        info = parsed.get("data", {}).get("gridInfoMap", {}).get(str(group_id), {})
        return {
            "name": info.get("name", "(Không rõ tên)"),
            "totalMember": info.get("totalMember", "?")
        }

    def fetch_friends(self):
        url = "https://profile-wpa.chat.zalo.me/api/social/friend/getfriends"
        params = {"zpw_ver": 645, "zpw_type": 30}
        encoded = zalo_encode({"offset": 0, "count": 1000}, self.secret_key)
        response = self.session.post(url, params=params, data={"params": encoded})
        result = response.json()
        decrypted = zalo_decode(result["data"], self.secret_key)
        parsed = json.loads(decrypted)
        data_section = parsed.get("data", [])
        if isinstance(data_section, list):
            users = data_section
        else:
            users = data_section.get("users", [])
        return [{"id": u.get("userId"), "name": u.get("zaloName", "(Không rõ tên)")} for u in users]

    def send_message(self, message, thread_id, thread_type, ttl=0):
        url = "https://tt-group-wpa.chat.zalo.me/api/group/sendmsg" if thread_type == ThreadType.GROUP else "https://tt-chat2-wpa.chat.zalo.me/api/message/sms"
        payload = {
            "message": message,
            "clientId": str(now()),
            "imei": self.imei,
            "ttl": ttl
        }
        if thread_type == ThreadType.GROUP:
            payload["visibility"] = 0
            payload["grid"] = str(thread_id)
        else:
            payload["toid"] = str(thread_id)
        encoded = zalo_encode(payload, self.secret_key)
        response = self.session.post(url, params={"zpw_ver": 645, "zpw_type": 30}, data={"params": encoded})
        return response.json()

class SpamTool(ZaloAPI):
    def __init__(self, name, imei, cookies, thread_ids, thread_type):
        super().__init__(imei, cookies)
        self.name = name
        self.thread_ids = thread_ids
        self.thread_type = thread_type
        self.start_time = time.time()
        self.running = False

    def send_spam(self, message, delay):
        self.running = True
        while self.running:
            for thread_id in self.thread_ids:
                try:
                    result = self.send_message(message, thread_id, self.thread_type, ttl=9000000000000)
                    status = "✅ Tool By Pham Long Da Treo" if result.get("error_code") == 0 else f"❌ Thất bại: {result}"
                    print(f"[{self.name}] {status} -> {thread_id}")
                except Exception as e:
                    print(f"[{self.name}] ❌ Lỗi gửi tới {thread_id}: {e}")
                time.sleep(delay)

def get_input(prompt, type_func=str, validator=None):
    while True:
        try:
            value = type_func(input(prompt).strip())
            if validator is None or validator(value):
                return value
        except:
            pass

def main():
    num = get_input("🔢 Nhập số tài khoản(tk muốn chạy): ", int, lambda x: x > 0)
    accounts = []

    for i in range(num):
        print(f"\n👤 Tài khoản #{i+1}")
        imei = input("🔑 IMEI: ").strip()
        cookies = json.loads(input("🍪 Cookie (JSON): ").strip())
        api = ZaloAPI(imei, cookies)

        mode = get_input("📤 Chọn kiểu spam (1 = Group, 2 = 1-1): ", int, lambda x: x in [1, 2])
        if mode == 1:
            groups = api.fetch_groups()
            print("\n📋 Danh sách nhóm:")
            for idx, g in enumerate(groups, 1):
                print(f"{idx}. {g['name']} | ID: {g['id']} | 👥 {g['members']} thành viên")
            pick = input("👉 Nhập STT nhóm cần spam (phân cách bởi dấu phẩy): ").strip()
            ids = [groups[int(x)-1]["id"] for x in pick.split(",") if x.strip().isdigit()]
            accounts.append(SpamTool(f"TK{i+1}", imei, cookies, ids, ThreadType.GROUP))
        else:
            users = api.fetch_friends()
            print("\n📋 Danh sách bạn bè:")
            for idx, u in enumerate(users, 1):
                print(f"{idx}. {u['name']} | ID: {u['id']}")
            pick = input("👉 Nhập STT người cần spam (phân cách bởi dấu phẩy): ").strip()
            ids = [users[int(x)-1]["id"] for x in pick.split(",") if x.strip().isdigit()]
            accounts.append(SpamTool(f"TK{i+1}", imei, cookies, ids, ThreadType.USER))

    txt_path = get_input("📝 File nội dung spam (.txt): ", str, os.path.exists)
    with open(txt_path, 'r', encoding='utf-8') as f:
        message = f.read().strip()

    delay = get_input("⏱️ Delay (giây): ", float, lambda x: x >= 0.5)

    threads = []
    for tool in accounts:
        t = threading.Thread(target=tool.send_spam, args=(message, delay))
        t.daemon = True
        threads.append(t)
        t.start()
        time.sleep(0.3)

    for t in threads:
        t.join()

if __name__ == "__main__":
    main()