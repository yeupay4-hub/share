import os
import site
import sys

hinhnen = """
⠤⣤⣤⣤⣄⣀⣀⣀⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣀⣠⣤⠤⠤⠴⠶⠶⠶⠶
⢠⣤⣤⡄⣤⣤⣤⠄⣀⠉⣉⣙⠒⠤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⠴⠘⣉⢡⣤⡤⠐⣶⡆⢶⠀⣶⣶⡦
⣄⢻⣿⣧⠻⠇⠋⠀⠋⠀⢘⣿⢳⣦⣌⠳⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠞⣡⣴⣧⠻⣄⢸⣿⣿⡟⢁⡻⣸⣿⡿⠁
⠈⠃⠙⢿⣧⣙⠶⣿⣿⡷⢘⣡⣿⣿⣿⣷⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣾⣿⣿⣿⣷⣝⡳⠶⠶⠾⣛⣵⡿⠋⠀⠀
⠀⠀⠀⠀⠉⠻⣿⣶⠂⠘⠛⠛⠛⢛⡛⠋⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠉⠛⠀⠉⠒⠛⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣿⡇⠀⠀⠀⠀⠀⢸⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣿⡇⠀⠀⠀⠀⠀⣾⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣿⡇⠀⠀⠀⠀⠀⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢻⡁⠀⠀⠀⠀⠀⢸⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠘⡇⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀ ⠀⠀⠀⠿
"""
print(hinhnen)
print("\n-> Author: Anhnguyencoder")
print("[INFO] https://www.facebook.com/anhnguyencoder.izumkonata\n")
print(f"[INFO] Python version: {sys.version.split()[0]}")
if sys.version_info < (3, 7):
    print("[!] Python quá cũ, nên dùng 3.8+ trở lên.")
print()

HOOK_CODE = r'''
import sys, types, socket, os, time, struct
from functools import wraps
from urllib.parse import urlparse

BroBiNgaoAk = __import__("os").path.join(__import__("os").getcwd(), "debug.txt")

def luufile(msg):
    try:
        with open(BroBiNgaoAk, "a", encoding="utf-8") as f:
            f.write(msg + "\n")
    except:pass

NgaoCakDaiDoanCuoiBaBa = socket.getaddrinfo
def hooked_getaddrinfo(host, port, family=0, type=0, proto=0, flags=0):
    msg = f"[GETADDRINFO] {host}:{port}"
    print(msg)
    luufile(msg)
    return NgaoCakDaiDoanCuoiBaBa(host, port, family, type, proto, flags)
socket.getaddrinfo = hooked_getaddrinfo

original_create_connection = socket.create_connection
def hooked_create_connection(address, timeout=None, source_address=None):
    host, port = address
    msg = f"[CREATE_CONNECTION] {host}:{port}"
    print(msg)
    luufile(msg)
    return original_create_connection(address, timeout, source_address)
socket.create_connection = hooked_create_connection

original_socket_connect = socket.socket.connect
original_socket_send = socket.socket.send
original_socket_sendto = socket.socket.sendto

def extract_host_from_addr(addr):
    if isinstance(addr, tuple) and len(addr) >= 1:
        return addr[0]
    return str(addr)

def bypasshooksocket(self, addr):
    host = extract_host_from_addr(addr)
    msg = f"[SOCKET-CONNECT] {host}"
    print(msg)
    luufile(msg)
    return original_socket_connect(self, addr)

def dmAINqu(self, data, flags=0):
    try:
        if isinstance(data, bytes):
            decoded = data.decode('utf-8', errors='ignore')
            if decoded.strip():
                lines = decoded.split('\r\n')
                for i, line in enumerate(lines[:10]):
                    if line.strip():
                        if 'GET ' in line or 'POST ' in line or 'PUT ' in line or 'DELETE ' in line or 'Host:' in line or 'User-Agent:' in line:
                            msg = f"[SOCKET-SEND] {line.strip()}"
                            __import__('sys').stdout.write(f'\n{msg}\n')
                            luufile(msg)
    except:pass
    return original_socket_send(self, data, flags)

def capdobadaolevel1000(self, data, addr):
    host = extract_host_from_addr(addr)
    msg = f"[SOCKET-SENDTO] {host}"
    __import__('sys').stdout.write(f'\n{msg}\n')
    luufile(msg)
    return original_socket_sendto(self, data, addr)

try:
    socket.socket.connect = bypasshooksocket
    socket.socket.send = dmAINqu
    socket.socket.sendto = capdobadaolevel1000
    luufile("[*] HOOKED SOCKET (connect, send, sendto, getaddrinfo, create_connection)")
except Exception as e:luufile(f"[!] Socket hook error: {e}")

try:
    import http.client
    thangchodien = http.client.HTTPConnection.putrequest
    def ditmechodup(self, method, url, *args, **kwargs):
        msg = f"[HTTP-CLIENT] {method} {url}"
        __import__('sys').stdout.write(f'\n{msg}\n')
        luufile(msg)
        return thangchodien(self, method, url, *args, **kwargs)
    http.client.HTTPConnection.putrequest = ditmechodup
    thangchodien_header = http.client.HTTPConnection.putheader
    def djtmenhamay(self, header, value, *args, **kwargs):
        if header.lower() == "host":
            msg = f"[HTTP-CLIENT-HOST] {value}"
            __import__('sys').stdout.write(f'\n{msg}\n')
            luufile(msg)
        else:
            msg = f"[HTTP-CLIENT-HEADER] {header}: {value}"
            __import__('sys').stdout.write(f'\n{msg}\n')
            luufile(msg)
        return thangchodien_header(self, header, value, *args, **kwargs)
    http.client.HTTPConnection.putheader = djtmenhamay
    thangchodien_end = http.client.HTTPConnection.endheaders
    def hooked_endheaders(self, *args, **kwargs):
        msg = f"[HTTP-CLIENT] ENDHEADERS - Gửi request hoàn tất"
        __import__('sys').stdout.write(f'\n{msg}\n')
        luufile(msg)
        return thangchodien_end(self, *args, **kwargs)
    http.client.HTTPConnection.endheaders = hooked_endheaders
    if hasattr(http.client, 'HTTPSConnection'):
        http.client.HTTPSConnection.putrequest = ditmechodup
        http.client.HTTPSConnection.putheader = djtmenhamay
        http.client.HTTPSConnection.endheaders = hooked_endheaders
    luufile("[*] Hooked http.client (HTTP + HTTPS)")
    print("[*] Hooked http.client !")
except Exception as e:luufile(f"[!] http.client hook error: {e}")

def BoBaNhatTheGioi():
    try:
        import requests
        import requests.api
        import requests.sessions
        original_get = requests.get
        original_post = requests.post
        original_put = requests.put
        original_delete = requests.delete
        original_patch = requests.patch
        original_request = requests.request
        original_session_send = requests.sessions.Session.send
        
        @wraps(original_get)
        def hooked_get(url, *args, **kwargs):
            msg = f"[GET] {url}"
            __import__('sys').stdout.write(f'\n{msg}\n')
            luufile(msg)
            return original_get(url, *args, **kwargs)
        
        @wraps(original_post)
        def hooked_post(url, *args, **kwargs):
            msg = f"[POST] {url}"
            __import__('sys').stdout.write(f'\n{msg}\n')
            luufile(msg)
            return original_post(url, *args, **kwargs)
        
        @wraps(original_put)
        def hooked_put(url, *args, **kwargs):
            msg = f"[PUT] {url}"
            __import__('sys').stdout.write(f'\n{msg}\n')
            luufile(msg)
            return original_put(url, *args, **kwargs)
        
        @wraps(original_delete)
        def hooked_delete(url, *args, **kwargs):
            msg = f"[DELETE] {url}"
            __import__('sys').stdout.write(f'\n{msg}\n')
            luufile(msg)
            return original_delete(url, *args, **kwargs)
        
        @wraps(original_patch)
        def hooked_patch(url, *args, **kwargs):
            msg = f"[PATCH] {url}"
            __import__('sys').stdout.write(f'\n{msg}\n')
            luufile(msg)
            return original_patch(url, *args, **kwargs)
        
        @wraps(original_request)
        def hooked_request(method, url, *args, **kwargs):
            msg = f"[REQUEST] {method.upper()} {url}"
            __import__('sys').stdout.write(f'\n{msg}\n')
            luufile(msg)
            return original_request(method, url, *args, **kwargs)
        
        @wraps(original_session_send)
        def hooked_session_send(self, request, *args, **kwargs):
            msg = f"[SESSION.SEND] {request.method} {request.url}"
            __import__('sys').stdout.write(f'\n{msg}\n')
            luufile(msg)
            if hasattr(request, 'headers'):
                for h, v in list(request.headers.items())[:5]:
                    luufile(f"  Header: {h}: {v}")
            return original_session_send(self, request, *args, **kwargs)
        
        requests.get = hooked_get
        requests.post = hooked_post
        requests.put = hooked_put
        requests.delete = hooked_delete
        requests.patch = hooked_patch
        requests.request = hooked_request
        requests.api.get = hooked_get
        requests.api.post = hooked_post
        requests.api.put = hooked_put
        requests.api.delete = hooked_delete
        requests.api.patch = hooked_patch
        requests.api.request = hooked_request
        requests.sessions.Session.send = hooked_session_send
        luufile("=== HOOK REQUESTS INJECTED ===")
        print("[*] Hooked requests module in memory")
    except ImportError:pass
    except Exception as e:luufile(f"Error hooking requests: {e}")

def var_con_cak():
    try:
        import urllib3.connectionpool
        import urllib3.poolmanager
        OcCakGiaiDoanCuoi = urllib3.connectionpool.HTTPConnectionPool.urlopen
        def hooked_urlopen(self, method, url, *args, **kwargs):
            scheme = "https" if self.scheme == "https" else "http"
            full_url = f"{scheme}://{self.host}{url}"
            msg = f"[URLLIB3] {method} {full_url}"
            __import__('sys').stdout.write(f'\n{msg}\n')
            luufile(msg)
            return OcCakGiaiDoanCuoi(self, method, url, *args, **kwargs)
        urllib3.connectionpool.HTTPConnectionPool.urlopen = hooked_urlopen
        if hasattr(urllib3.poolmanager, 'PoolManager'):
            original_pool_request = urllib3.poolmanager.PoolManager.request
            def hooked_pool_request(self, method, url, *args, **kwargs):
                msg = f"[URLLIB3-POOL] {method} {url}"
                __import__('sys').stdout.write(f'\n{msg}\n')
                luufile(msg)
                return original_pool_request(self, method, url, *args, **kwargs)
            urllib3.poolmanager.PoolManager.request = hooked_pool_request
        luufile("[*] Hooked urllib3 in memory (urlopen + PoolManager)")
        print("[*] Hooked urllib3 in memory !")
    except ImportError:pass
    except Exception as e:luufile(f"Error hooking urllib3: {e}")

def BaChuThienHa():
    try:
        import requests.sessions
        PheVatGiaiDoanCuoi = requests.sessions.Session.request
        def hooked_session_request(self, method, url, *args, **kwargs):
            msg = f"[SESSION] {method} {url}"
            __import__('sys').stdout.write(f'\n{msg}\n')
            luufile(msg)
            return PheVatGiaiDoanCuoi(self, method, url, *args, **kwargs)
        requests.sessions.Session.request = hooked_session_request
        luufile("[*] Hooked Session.request in memory")
        print("[*] Hooked Session.request in memory")
    except ImportError:pass
    except Exception as e:luufile(f"Error hooking session: {e}")

def namanhsitrum():
    try:
        import aiohttp.client
        bohookchocmayxemnek = aiohttp.client.ClientSession._request
        async def hooked_aio_request(self, method, url, *args, **kwargs):
            url_str = str(url) if hasattr(url, 'human_repr') else str(url)
            msg = f"[AIOHTTP] {method.upper()} {url_str}"
            __import__('sys').stdout.write(f'\n{msg}\n')
            luufile(msg)
            return await bohookchocmayxemnek(self, method, url, *args, **kwargs)
        aiohttp.client.ClientSession._request = hooked_aio_request
        luufile("[*] Hooked aiohttp in memory !")
        print("[*] Hooked aiohttp in memory !")
    except ImportError:pass
    except Exception as e:luufile(f"Error hooking aiohttp: {e}")

def DitMeMay():
    try:
        import httpx
        dmcayak = httpx.Client.request
        hieuko = httpx.AsyncClient.request
        
        def hooked_client_request(self, method, url, *args, **kwargs):
            msg = f"[HTTPX-CLIENT] {method.upper()} {url}"
            __import__('sys').stdout.write(f'\n{msg}\n')
            luufile(msg)
            return dmcayak(self, method, url, *args, **kwargs)
        
        async def hooked_async_client_request(self, method, url, *args, **kwargs):
            msg = f"[HTTPX-ASYNC] {method.upper()} {url}"
            __import__('sys').stdout.write(f'\n{msg}\n')
            luufile(msg)
            return await hieuko(self, method, url, *args, **kwargs)
        
        httpx.Client.request = hooked_client_request
        httpx.AsyncClient.request = hooked_async_client_request
        
        _orig_get = httpx.get
        _orig_post = httpx.post
        _orig_put = httpx.put
        _orig_delete = httpx.delete
        
        def kieunophaithe(url, *args, **kwargs):
            msg = f"[HTTPX-GET] {url}"
            __import__('sys').stdout.write(f'\n{msg}\n')
            luufile(msg)
            return _orig_get(url, *args, **kwargs)
        
        def ukanksairoii(url, *args, **kwargs):
            msg = f"[HTTPX-POST] {url}"
            __import__('sys').stdout.write(f'\n{msg}\n')
            luufile(msg)
            return _orig_post(url, *args, **kwargs)
        
        def hooked_put(url, *args, **kwargs):
            msg = f"[HTTPX-PUT] {url}"
            __import__('sys').stdout.write(f'\n{msg}\n')
            luufile(msg)
            return _orig_put(url, *args, **kwargs)
        
        def hooked_delete(url, *args, **kwargs):
            msg = f"[HTTPX-DELETE] {url}"
            __import__('sys').stdout.write(f'\n{msg}\n')
            luufile(msg)
            return _orig_delete(url, *args, **kwargs)
        
        httpx.get = kieunophaithe
        httpx.post = ukanksairoii
        httpx.put = hooked_put
        httpx.delete = hooked_delete
        
        luufile("[*] Hooked httpx in memory (sync + async)")
    except ImportError:pass
    except Exception as e:luufile(f"Error hooking httpx: {e}")

def BoBaSanInject():
    try:
        import urllib.request
        djtmeongaovailol = urllib.request.OpenerDirector.open
        def bothicthe(self, fullurl, *args, **kwargs):
            msg = f"[URLLIB.REQUEST] {fullurl}"
            __import__('sys').stdout.write(f'\n{msg}\n')
            luufile(msg)
            return djtmeongaovailol(self, fullurl, *args, **kwargs)
        urllib.request.OpenerDirector.open = bothicthe
        luufile("[*] Hooked urllib.request")
        print("[*] Urlib Hooks Successfully Stored in Memory!")
    except Exception as e:luufile(f"[!] urllib.request hook error: {e}")

def HookBaDao():
    try:
        import urllib.request
        orig_http_open = urllib.request.HTTPHandler.http_open
        orig_https_open = urllib.request.HTTPSHandler.https_open
        def hooked_http_open(self, req):
            msg = f"[HTTP-HANDLER] {req.get_method()} {req.full_url}"
            __import__('sys').stdout.write(f'\n{msg}\n')
            luufile(msg)
            return orig_http_open(self, req)
        def hooked_https_open(self, req):
            msg = f"[HTTPS-HANDLER] {req.get_method()} {req.full_url}"
            __import__('sys').stdout.write(f'\n{msg}\n')
            luufile(msg)
            return orig_https_open(self, req)
        urllib.request.HTTPHandler.http_open = hooked_http_open
        urllib.request.HTTPSHandler.https_open = hooked_https_open
        luufile("[*] Hooked HTTP/HTTPS handlers")
        print("[*] HTTP/HTTPS hook successful!")
    except Exception as e:luufile(f"[!] HTTP handler hook error: {e}")

def BOLAANHNGUYENHAHA():
    try:
        import http.cookiejar
        orig_set_cookie = http.cookiejar.CookieJar.set_cookie
        def hooked_set_cookie(self, cookie):
            msg = f"[>>] Domain: {cookie.domain}, Name: {cookie.name}, Value: {cookie.value[:20]}..."
            __import__('sys').stdout.write(f'\n{msg}\n')
            luufile(msg)
            return orig_set_cookie(self, cookie)
        http.cookiejar.CookieJar.set_cookie = hooked_set_cookie
        luufile("[*] Hooked CookieJar")
    except Exception as e:luufile(f"Cookie hook error: {e}")

luufile(f">> AnhNguyenCoder Bá Đạo Tuyệt Đối <<")
luufile(f"\n===== BYPASS ANTI-HOOK + FULL URL/HOST/HEADER CAPTURE ===== {__import__('datetime').datetime.now()}")

#BoBaNhatTheGioi()
#BaChuThienHa()
#var_con_cak()
#namanhsitrum()
#DitMeMay()
#BoBaSanInject()
#HookBaDao()
#BOLAANHNGUYENHAHA()

luufile("===== HOOK CREATION PROCESS COMPLETE =====\n")
print(">> Bypass ANTI-HOOK (Enhanced) <<")
print(">> NẾU BẠN KHÔNG THẤY HIỆN URL THÌ URL SẼ Ở TRONG FILE LOG debug.txt <<")
print(">> ĐÃ HOOK: getaddrinfo, create_connection, socket.send, requests, urllib3, httpx, aiohttp, cookie, ... <<")
'''

HOOK_CODE1 = r'''import hook'''

def get_sitecustomize_path():
    user_site = site.getusersitepackages()
    os.makedirs(user_site, exist_ok=True)
    return os.path.join(user_site, "hook.py")

def get_sitecustomize_path1():
    user_site = site.getusersitepackages()
    os.makedirs(user_site, exist_ok=True)
    return os.path.join(user_site, "inject.pth")

def tai_hook():
    path1 = get_sitecustomize_path()
    path2 = get_sitecustomize_path1()
#    path = path1 + path2
    with open(path1, "w", encoding="utf-8") as f:
        f.write(HOOK_CODE)
    with open(path2, "w", encoding="utf-8") as f:
        f.write(HOOK_CODE1)
    print("Success Hook!")
#    print(f"[+] Hook installed at: {path1}")
#    print(f"[+] Hook installed at: {path2}")

def xoa_hook():
    path1 = get_sitecustomize_path()
    path2 = get_sitecustomize_path1()

    removed = False

    if os.path.exists(path1):
        os.remove(path1)
#        print(f"[+] xoá: {path1}")
        removed = True

    if os.path.exists(path2):
        os.remove(path2)
#        print(f"[+] xoá: {path2}")
        removed = True

    if removed:
        print("[+] Success Hook Removed!")
    else:
        print("[!] No hook found.")

if __name__ == "__main__":
    print("1. Install hook")
    print("2. Remove hook")
    choice = input(">> ")

    if choice == "1":
        tai_hook()
    elif choice == "2":
        xoa_hook()
    else:
        print("Chọn sai rồi nhóc!")