import discord
from discord.ext import commands
import asyncio, time, os, sys
from sys import platform
from pystyle import Add,Center,Anime,Colors,Colorate,Write,System
from pystyle import *

import requests,json,os,sys
from sys import platform
from datetime import datetime        
from time import sleep,strftime
try:
    from pystyle import Add,Center,Anime,Colors,Colorate,Write,System
except:
    os.system('pip install pystyle requests colorama beautifulsoup4 selenium mechanize webdriver_manager')
    from pystyle import Add,Center,Anime,Colors,Colorate,Write,System

sys.setrecursionlimit(99999999)        
ver = str(sys.version_info.major)+'.'+str(sys.version_info.minor)

try:
    from sys import platform
    from pystyle import Add,Center,Anime,Colors,Colorate,Write,System
    from sys import platform
    import sys, requests,json,os,sys,discord
    import asyncio, time, os, sys
    from pystyle import *
except ModuleNotFoundError:
    print('>> Installing Module')
    __import__('os').system(f'pip{ver} install pystyle')
    from pystyle import *
System.Clear()

def clear():
    if platform[0:3]=='lin':
        os.system('clear')
    else:
        os.system('cls')
        
text = """
▄▄▄█████▓ ██▀███  ▓█████  ▒█████  ▓█████▄  ██▓  ██████  ▄████▄   ▒█████   ██▀███  ▓█████▄ 
▓  ██▒ ▓▒▓██ ▒ ██▒▓█   ▀ ▒██▒  ██▒▒██▀ ██▌▓██▒▒██    ▒ ▒██▀ ▀█  ▒██▒  ██▒▓██ ▒ ██▒▒██▀ ██▌
▒ ▓██░ ▒░▓██ ░▄█ ▒▒███   ▒██░  ██▒░██   █▌▒██▒░ ▓██▄   ▒▓█    ▄ ▒██░  ██▒▓██ ░▄█ ▒░██   █▌
░ ▓██▓ ░ ▒██▀▀█▄  ▒▓█  ▄ ▒██   ██░░▓█▄   ▌░██░  ▒   ██▒▒▓▓▄ ▄██▒▒██   ██░▒██▀▀█▄  ░▓█▄   ▌
  ▒██▒ ░ ░██▓ ▒██▒░▒████▒░ ████▓▒░░▒████▓ ░██░▒██████▒▒▒ ▓███▀ ░░ ████▓▒░░██▓ ▒██▒░▒████▓ 
  ▒ ░░   ░ ▒▓ ░▒▓░░░ ▒░ ░░ ▒░▒░▒░  ▒▒▓  ▒ ░▓  ▒ ▒▓▒ ▒ ░░ ░▒ ▒  ░░ ▒░▒░▒░ ░ ▒▓ ░▒▓░ ▒▒▓  ▒ 
    ░      ░▒ ░ ▒░ ░ ░  ░  ░ ▒ ▒░  ░ ▒  ▒  ▒ ░░ ░▒  ░ ░  ░  ▒     ░ ▒ ▒░   ░▒ ░ ▒░ ░ ▒  ▒ 
  ░        ░░   ░    ░   ░ ░ ░ ▒   ░ ░  ░  ▒ ░░  ░  ░  ░        ░ ░ ░ ▒    ░░   ░  ░ ░  ░ 
            ░        ░  ░    ░ ░     ░     ░        ░  ░ ░          ░ ░     ░        ░    
                                   ░                   ░                           ░

                            Author: 𝘼𝙣𝙝𝙉𝙜𝙪𝙮𝙚𝙣𝘾𝙤𝙙𝙚𝙧🧸"""
#print(banner)

def banner():
    print('\x1b[0m',end='')
    clear()
    a=Colorate.Diagonal(Colors.DynamicMIX((Col.purple, Col.blue)), text)
    for i in range(len(a)):
        sys.stdout.write(a[i])
        sys.stdout.flush()

banner()
print()

dark = Col.dark_gray
light = Col.light_gray

def stage(text: str, symbol: str = '>>', col1=None) -> str:
    if col1 is None:
        col1 = light
    return f" {Col.Symbol(symbol, col1, dark)} {text}{light}"

TOKEN = input(stage(Colorate.Diagonal(Colors.DynamicMIX((Col.blue, Col.green)), "Nhập Bot Token: ")))
CHANNEL_ID = int(input(stage(Colorate.Diagonal(Colors.DynamicMIX((Col.blue, Col.green)), ("Nhập Channel ID: ")))))

# Nhập tên file txt
filename = input(stage(Colorate.Diagonal(Colors.DynamicMIX((Col.blue, Col.green)), "Nhập File Nhây (VD: nhay.txt): ")))

try:
    with open(filename, "r", encoding="utf-8") as file:
        questions = [line.strip() for line in file.readlines() if line.strip()]
    print(Colorate.Horizontal(Colors.green_to_cyan, f"✅ Đã đọc {len(questions)} câu hỏi từ file: {filename}"))
    for i, q in enumerate(questions, 1):
        pass
except FileNotFoundError:
    print(Colorate.Diagonal(Colors.DynamicMIX((Col.red, Col.gray)), f"❌ Không tìm thấy file {filename}!"))
    exit()
except Exception as e:
    print(Colorate.Diagonal(Colors.DynamicMIX((Col.red, Col.gray)), f"❌ Lỗi đọc file: {e}"))
    exit()

options = ["Hotwar", "Bá War", "Anh Bá?"]

poll_duration = int(input(stage(Colorate.Diagonal(Colors.DynamicMIX((Col.blue, Col.green)), "Thời gian huỷ mỗi poll (giây): "))))
delay_between_polls = int(input(stage(Colorate.Diagonal(Colors.DynamicMIX((Col.blue, Col.green)), "Delay (giây): "))))
#loop_count = int(input("Số lần gửi (0 = vô hạn): "))
loop_count = 0

intents = discord.Intents.default()
bot = commands.Bot(command_prefix="!", intents=intents)

class PollView(discord.ui.View):
    def __init__(self, options, duration, question_text):
        super().__init__(timeout=duration)
        self.voters = set()
        self.votes = {opt: 0 for opt in options}
        self.options = options
        self.question_text = question_text

        for opt in options:
            self.add_item(self.create_button(opt))

    def create_button(self, option):
        async def button_callback(interaction: discord.Interaction):
            if interaction.user.id in self.voters:
                await interaction.response.send_message(
                    "❌ Bạn đã vote rồi!", ephemeral=True
                )
                return

            self.voters.add(interaction.user.id)
            self.votes[option] += 1
            await interaction.response.send_message(
                f"✅ Bạn chọn: {option}", ephemeral=True
            )

        return discord.ui.Button(
            label=option,
            style=discord.ButtonStyle.primary,
            custom_id=option,
            row=0,
        ).__class__(
            label=option,
            style=discord.ButtonStyle.primary,
            custom_id=option,
        )

    async def interaction_check(self, interaction: discord.Interaction):
        return True

    async def on_timeout(self):
        for item in self.children:
            item.disabled = True

        results = "\n".join(
            [f"**{opt}**: {count} vote" for opt, count in self.votes.items()]
        )

        embed = discord.Embed(
            title="🤬 Đéo Chọn à!",
            description=f"{self.question_text}\n\n{results}",
            color=discord.Color.green(),
        )

        try:
            await self.message.edit(embed=embed, view=self)
        except:
            pass


async def send_poll(channel, question_text):
    view = PollView(options, poll_duration, question_text)

    embed = discord.Embed(
        title="🧸 Hot War Treo Discord",
        description=question_text,
        color=discord.Color.blue(),
    )
#    embed.set_footer(text=f"Poll kết thúc sau {poll_duration} giây")

    msg = await channel.send(embed=embed, view=view)
    view.message = msg
    return msg

@bot.event
async def on_ready():
    print(f"Đã đăng nhập: {bot.user}")
    channel = bot.get_channel(CHANNEL_ID)

    if channel is None:
        print("❌ Không tìm thấy channel!")
        await bot.close()
        return

    print(f"Bắt đầu gửi poll đến #{channel.name}...")
    print(f"Tổng số câu hỏi: {len(questions)}")
    print(f"Delay giữa các poll: {delay_between_polls} giây")
#    print(f"Số lần lặp: {'Vô hạn' if loop_count == 0 else loop_count}")
    print("-" * 50)

    try:
        count = 0
        while True:
            for i, question_text in enumerate(questions, 1):
                print(f"[{time.strftime('%H:%M:%S')}] Đang gửi poll {i}: {question_text[:50]}...")
                await send_poll(channel, question_text)
                
                if i < len(questions) or loop_count != 0:
                    print(f"  Chờ {delay_between_polls} giây...")
                    await asyncio.sleep(delay_between_polls)
            
            count += 1
            if loop_count > 0 and count >= loop_count:
                print(f"✅ Đã hoàn thành {loop_count} lần lặp!")
                break
                
    except asyncio.CancelledError:
        print(Colorate.Horizontal(Colors.green_to_cyan, "✅ Đã dừng gửi poll!"))
    except Exception as e:
        print(Colorate.Diagonal(Colors.DynamicMIX((Col.red, Col.gray)), f"❌ Lỗi: {e}"))
    finally:
        await bot.close()

bot.run(TOKEN)