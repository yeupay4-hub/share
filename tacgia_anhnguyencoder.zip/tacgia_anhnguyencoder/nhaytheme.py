import os
import sys
import time
import json
import random
import hashlib
import threading
from collections import defaultdict
from urllib.parse import urlparse, urlencode
from datetime import datetime
import requests
import psutil
import gc
import paho.mqtt.client as mqtt
import ssl
import re
import string
import pyfiglet
from termcolor import colored

cookie_attempts = defaultdict(lambda: {'count': 0, 'last_reset': time.time(), 'banned_until': 0, 'permanent_ban': False})
active_threads = {}
cleanup_lock = threading.Lock()

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def banner():
    ascii_banner = pyfiglet.figlet_format("   THEME", font="slant")
    print(colored(ascii_banner, 'cyan', attrs=['bold']))
    print("=" * 60)
    print(colored("       Tool Change Theme By Cte Vcl", 'white', attrs=['bold']))
    print("=" * 60)

def handle_failed_connection(cookie_hash):
    global cookie_attempts
    
    current_time = time.time()
    
    if current_time - cookie_attempts[cookie_hash]['last_reset'] > 43200:
        cookie_attempts[cookie_hash]['count'] = 0
        cookie_attempts[cookie_hash]['last_reset'] = current_time
        cookie_attempts[cookie_hash]['banned_until'] = 0
    
    if cookie_attempts[cookie_hash]['banned_until'] > 0:
        ban_count = getattr(cookie_attempts[cookie_hash], 'ban_count', 0) + 1
        cookie_attempts[cookie_hash]['ban_count'] = ban_count
        
        if ban_count >= 5:
            cookie_attempts[cookie_hash]['permanent_ban'] = True
            print(f"Cookie {cookie_hash[:10]} Đã Bị Ngưng Hoạt Động Vĩnh Viễn Để Tránh Đầy Memory, Lí Do: Acc Die, CheckPoint v.v")
            
            for key in list(active_threads.keys()):
                if key.startswith(cookie_hash):
                    active_threads[key].stop()
                    del active_threads[key]

def cleanup_global_memory():
    global active_threads, cookie_attempts
    
    with cleanup_lock:
        current_time = time.time()
        
        expired_cookies = []
        for cookie_hash, data in cookie_attempts.items():
            if data['permanent_ban'] or (current_time - data['last_reset'] > 86400):
                expired_cookies.append(cookie_hash)
        
        for cookie_hash in expired_cookies:
            del cookie_attempts[cookie_hash]
            for key in list(active_threads.keys()):
                if key.startswith(cookie_hash):
                    active_threads[key].stop()
                    del active_threads[key]
        
        gc.collect()
        
        process = psutil.Process()
        memory_info = process.memory_info()
        print(f"Memory Usage: {memory_info.rss / (1024**3):.2f} GB")

def parse_cookie_string(cookie_string):
    cookie_dict = {}
    cookies = cookie_string.split(";")
    for cookie in cookies:
        if "=" in cookie:
            key, value = cookie.strip().split("=", 1)
            cookie_dict[key] = value
    return cookie_dict

def generate_offline_threading_id() -> str:
    ret = int(time.time() * 1000)
    value = random.randint(0, 4294967295)
    binary_str = format(value, "022b")[-22:]
    msgs = bin(ret)[2:] + binary_str
    return str(int(msgs, 2))

def get_headers(url: str, options: dict = {}, ctx: dict = {}, customHeader: dict = {}) -> dict:
    headers = {
        "Accept-Encoding": "gzip, deflate",
        "Content-Type": "application/x-www-form-urlencoded",
        "Referer": "https://www.facebook.com/",
        "Host": urlparse(url).netloc,
        "Origin": "https://www.facebook.com",
        "User-Agent": "Mozilla/5.0 (Linux; Android 9; SM-G973U Build/PPR1.180610.011) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36",
        "Connection": "keep-alive",
    }

    if "user_agent" in options:
        headers["User-Agent"] = options["user_agent"]

    for key in customHeader:
        headers[key] = customHeader[key]

    if "region" in ctx:
        headers["X-MSGR-Region"] = ctx["region"]

    return headers

def json_minimal(data):
    return json.dumps(data, separators=(",", ":"))

class Counter:
    def __init__(self, initial_value=0):
        self.value = initial_value
        
    def increment(self):
        self.value += 1
        return self.value
        
    @property
    def counter(self):
        return self.value

def formAll(dataFB, FBApiReqFriendlyName=None, docID=None, requireGraphql=None):
    global _req_counter
    if '_req_counter' not in globals():
        _req_counter = Counter(0)
    
    __reg = _req_counter.increment()
    dataForm = {}
    
    if requireGraphql is None:
        dataForm["fb_dtsg"] = dataFB["fb_dtsg"]
        dataForm["jazoest"] = dataFB["jazoest"]
        dataForm["__a"] = 1
        dataForm["__user"] = str(dataFB["FacebookID"])
        dataForm["__req"] = str_base(__reg, 36) 
        dataForm["__rev"] = dataFB["clientRevision"]
        dataForm["av"] = dataFB["FacebookID"]
        dataForm["fb_api_caller_class"] = "RelayModern"
        dataForm["fb_api_req_friendly_name"] = FBApiReqFriendlyName
        dataForm["server_timestamps"] = "true"
        dataForm["doc_id"] = str(docID)
    else:
        dataForm["fb_dtsg"] = dataFB["fb_dtsg"]
        dataForm["jazoest"] = dataFB["jazoest"]
        dataForm["__a"] = 1
        dataForm["__user"] = str(dataFB["FacebookID"])
        dataForm["__req"] = str_base(__reg, 36) 
        dataForm["__rev"] = dataFB["clientRevision"]
        dataForm["av"] = dataFB["FacebookID"]

    return dataForm

def mainRequests(url, data, cookies):
    return {
        "url": url,
        "data": data,
        "headers": {
            "authority": "www.facebook.com",
            "accept": "*/*",
            "accept-language": "en-US,en;q=0.9,vi;q=0.8",
            "content-type": "application/x-www-form-urlencoded",
            "origin": "https://www.facebook.com",
            "referer": "https://www.facebook.com/",
            "sec-ch-ua": "\"Not?A_Brand\";v=\"8\", \"Chromium\";v=\"108\"",
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": "\"Windows\"",
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-origin",
            "user-agent": "Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36",
            "x-fb-friendly-name": "FriendingCometFriendRequestsRootQueryRelayPreloader",
            "x-fb-lsd": "YCb7tYCGWDI6JLU5Aexa1-"
        },
        "cookies": parse_cookie_string(cookies),
        "verify": True
    }

def digitToChar(digit):
    if digit < 10:
        return str(digit)
    return chr(ord('a') + digit - 10)

def str_base(number, base):
    if number < 0:
        return "-" + str_base(-number, base)
    (d, m) = divmod(number, base)
    if d > 0:
        return str_base(d, base) + digitToChar(m)
    return digitToChar(m)

def generate_session_id():
    return random.randint(1, 2 ** 53)

def generate_client_id():
    def gen(length):
        return "".join(random.choices(string.ascii_lowercase + string.digits, k=length))
    return gen(8) + '-' + gen(4) + '-' + gen(4) + '-' + gen(4) + '-' + gen(12)

# Lớp fbTools
class fbTools:
    def __init__(self, dataFB, threadID="0"):
        self.threadID = threadID
        self.dataGet = None
        self.dataFB = dataFB
        self.ProcessingTime = None
        self.last_seq_id = None
    
    def getAllThreadList(self):
        randomNumber = str(int(format(int(time.time() * 1000), "b") + ("0000000000000000000000" + format(int(random.random() * 4294967295), "b"))[-22:], 2))
        dataForm = formAll(self.dataFB, requireGraphql=0)

        dataForm["queries"] = json.dumps({
            "o0": {
                "doc_id": "3336396659757871",
                "query_params": {
                    "limit": 20,
                    "before": None,
                    "tags": ["INBOX"],
                    "includeDeliveryReceipts": False,
                    "includeSeqID": True,
                }
            }
        })
        
        sendRequests = requests.post(**mainRequests("https://www.facebook.com/api/graphqlbatch/", dataForm, self.dataFB["cookieFacebook"]))
        response_text = sendRequests.text
        self.ProcessingTime = sendRequests.elapsed.total_seconds()
        
        if response_text.startswith("for(;;);"):
            response_text = response_text[9:]
        
        if not response_text.strip():
            print("Error: Empty response from Facebook API")
            return False
            
        try:
            response_parts = response_text.split("\n")
            first_part = response_parts[0]
            
            if first_part.strip():
                response_data = json.loads(first_part)
                self.dataGet = first_part
                
                if "o0" in response_data and "data" in response_data["o0"] and "viewer" in response_data["o0"]["data"] and "message_threads" in response_data["o0"]["data"]["viewer"]:
                    self.last_seq_id = response_data["o0"]["data"]["viewer"]["message_threads"]["sync_sequence_id"]
                    return True
                else:
                    print("Error: Expected fields not found in response")
                    return False
            else:
                print("Error: Empty first part of response")
                return False
                
        except json.JSONDecodeError as e:
            print(f"JSON Decode Error: {e}")
            print(f"Response first part: {response_parts[0][:100]}")
            return False
        except KeyError as e:
            print(f"Key Error: {e}")
            print("The expected data structure wasn't found in the response")
            return False

class ThemeChanger:
    def __init__(self, fbt, dataFB, fb_instance):
        self.fbt = fbt
        self.dataFB = dataFB
        self.fb_instance = fb_instance
        self.mqtt = None
        self.ws_req_number = 0
        self.ws_task_number = 0
        self.syncToken = None
        self.lastSeqID = None
        self.req_callbacks = {}
        self.cookie_hash = hashlib.md5(dataFB['cookieFacebook'].encode()).hexdigest()
        self.connect_attempts = 0
        self.last_cleanup = time.time()

        self.THEMES = [
            {"id": "7644530931905589772", "name": "tuyết"},
            {"id": "619222974460043", "name": "tuyết"},
            {"id": "1103447831508663", "name": "Tron: Ares"},
            {"id": "3650637715209675", "name": "Besties"},
            {"id": "769656934577391", "name": "Women's History Month"},
            {"id": "702099018755409", "name": "Dune: Part Two"},
            {"id": "1480404512543552", "name": "Avatar: The Last Airbender"},
            {"id": "952656233130616", "name": "J.Lo"},
            {"id": "741311439775765", "name": "Love"},
            {"id": "215565958307259", "name": "Bob Marley: One Love"},
            {"id": "194982117007866", "name": "Football"},
            {"id": "1743641112805218", "name": "Soccer"},
            {"id": "730357905262632", "name": "Mean Girls"},
            {"id": "1270466356981452", "name": "Wonka"},
            {"id": "704702021720552", "name": "Pizza"},
            {"id": "1013083536414851", "name": "Wish"},
            {"id": "359537246600743", "name": "Trolls"},
            {"id": "173976782455615", "name": "The Marvels"},
            {"id": "2317258455139234", "name": "One Piece"},
            {"id": "6685081604943977", "name": "1989"},
            {"id": "1508524016651271", "name": "Avocado"},
            {"id": "265997946276694", "name": "Loki Season 2"},
            {"id": "6584393768293861", "name": "olivia rodrigo"},
            {"id": "845097890371902", "name": "Baseball"},
            {"id": "292955489929680", "name": "Lollipop"},
            {"id": "976389323536938", "name": "Loops"},
            {"id": "810978360551741", "name": "Parenthood"},
            {"id": "195296273246380", "name": "Bubble Tea"},
            {"id": "6026716157422736", "name": "Basketball"},
            {"id": "693996545771691", "name": "Elephants & Flowers"},
            {"id": "390127158985345", "name": "Chill"},
            {"id": "365557122117011", "name": "Support"},
            {"id": "339021464972092", "name": "Music"},
            {"id": "1060619084701625", "name": "Lo-Fi"},
            {"id": "3190514984517598", "name": "Sky"},
            {"id": "627144732056021", "name": "Celebration"},
            {"id": "275041734441112", "name": "Care"},
            {"id": "3082966625307060", "name": "Astrology"},
            {"id": "539927563794799", "name": "Cottagecore"},
            {"id": "527564631955494", "name": "Ocean"},
            {"id": "230032715012014", "name": "Tie-Dye"},
            {"id": "788274591712841", "name": "Monochrome"},
            {"id": "3259963564026002", "name": "Default"},
            {"id": "724096885023603", "name": "Berry"},
            {"id": "624266884847972", "name": "Candy"},
            {"id": "273728810607574", "name": "Unicorn"},
            {"id": "262191918210707", "name": "Tropical"},
            {"id": "2533652183614000", "name": "Maple"},
            {"id": "909695489504566", "name": "Sushi"},
            {"id": "582065306070020", "name": "Rocket"},
            {"id": "557344741607350", "name": "Citrus"},
            {"id": "280333826736184", "name": "Lollipop"},
            {"id": "271607034185782", "name": "Shadow"},
            {"id": "1257453361255152", "name": "Rose"},
            {"id": "571193503540759", "name": "Lavender"},
            {"id": "2873642949430623", "name": "Tulip"},
            {"id": "3273938616164733", "name": "Classic"},
            {"id": "403422283881973", "name": "Apple"},
            {"id": "3022526817824329", "name": "Peach"},
            {"id": "672058580051520", "name": "Honey"},
            {"id": "3151463484918004", "name": "Kiwi"},
            {"id": "736591620215564", "name": "Ocean"},
            {"id": "193497045377796", "name": "Grape"},
        ]

    def set_theme(self, theme_id, thread_id, callback=None):
        if self.mqtt is None:
            print("Error: Not Connected To MQTT")
            return False

        self.cleanup_memory()

        self.ws_req_number += 1
        self.ws_task_number += 1

        if not theme_id:
            selected_theme = random.choice(self.THEMES)
            theme_id = selected_theme["id"]
            theme_name = selected_theme["name"]
        else:
            selected_theme = next((theme for theme in self.THEMES if theme["id"] == theme_id), None)
            if not selected_theme:
                print(f"Error: Theme ID {theme_id} not found in available themes")
                return False
            theme_name = selected_theme["name"]

        task_payload = {
            "thread_key": thread_id,
            "theme_fbid": theme_id,
            "source": None,
            "sync_group": 1,
            "payload": None,
        }

        task = {
            "failure_count": None,
            "label": "43",
            "payload": json.dumps(task_payload, separators=(",", ":")),
            "queue_name": "thread_theme",
            "task_id": self.ws_task_number,
        }

        content = {
            "app_id": "2220391788200892",
            "payload": json.dumps({
                "data_trace_id": None,
                "epoch_id": int(generate_offline_threading_id()),
                "tasks": [task],
                "version_id": "25095469420099952",
            }, separators=(",", ":")),
            "request_id": self.ws_req_number,
            "type": 3,
        }

        if callback is not None and callable(callback):
            self.req_callbacks[self.ws_req_number] = callback

        try:
            self.mqtt.publish(
                topic="/ls_req",
                payload=json.dumps(content, separators=(",", ":")),
                qos=1,
                retain=False,
            )
            print(colored(f"[✓] Đã thay đổi theme thành: {theme_name} (ID: {theme_id}) cho box {thread_id}", 'green'))
            return True
        except Exception as e:
            print(colored(f"Error Publishing Theme Change: {e}", 'red'))
            return False
        
    def cleanup_memory(self):
        current_time = time.time()
        if current_time - self.last_cleanup > 3600:
            self.req_callbacks.clear()
            gc.collect()
            self.last_cleanup = current_time

    def get_last_seq_id(self):
        success = self.fbt.getAllThreadList()
        if success:
            self.lastSeqID = self.fbt.last_seq_id
        else:
            print(colored("Failed To Get Last Sequence ID. Check Facebook Authentication.", 'yellow'))
            return

    def on_disconnect(self, client, userdata, rc):
        global cookie_attempts
        print(colored(f"Disconnected With Code {rc}", 'yellow'))
        
        cookie_attempts[self.cookie_hash]['count'] += 1
        current_time = time.time()
        
        if current_time - cookie_attempts[self.cookie_hash]['last_reset'] > 43200:
            cookie_attempts[self.cookie_hash]['count'] = 1
            cookie_attempts[self.cookie_hash]['last_reset'] = current_time
        
        if cookie_attempts[self.cookie_hash]['count'] >= 20:
            print(colored(f"Cookie {self.cookie_hash[:10]} Bị Tạm Ngưng Connect Trong 12 Giờ Vì Disconnect, Nghi Vấn: Die Cookies, Check Point", 'red'))
            cookie_attempts[self.cookie_hash]['banned_until'] = current_time + 43200
            return
        
        if rc != 0:
            print(colored("Attempting To Reconnect...", 'yellow'))
            try:
                time.sleep(min(cookie_attempts[self.cookie_hash]['count'] * 2, 30))
                client.reconnect()
            except:
                print(colored("Reconnect Failed", 'red'))

    def _messenger_queue_publish(self, client, userdata, flags, rc):
        print(colored(f"Connected To MQTT With Code: {rc}", 'green'))
        if rc != 0:
            print(colored(f"Connection Failed With Code {rc}", 'red'))
            return

        topics = [("/t_ms", 0)]
        client.subscribe(topics)

        queue = {
            "sync_api_version": 10,
            "max_deltas_able_to_process": 1000,
            "delta_batch_size": 500,
            "encoding": "JSON",
            "entity_fbid": self.dataFB['FacebookID']
        }

        if self.syncToken is None:
            topic = "/messenger_sync_create_queue"
            queue["initial_titan_sequence_id"] = self.lastSeqID
            queue["device_params"] = None
        else:
            topic = "/messenger_sync_get_diffs"
            queue["last_seq_id"] = self.lastSeqID
            queue["sync_token"] = self.syncToken

        print(colored(f"Publishing To {topic}", 'cyan'))
        client.publish(
            topic,
            json_minimal(queue),
            qos=1,
            retain=False,
        )

    def connect_mqtt(self):
        global cookie_attempts
        
        if cookie_attempts[self.cookie_hash]['permanent_ban']:
            print(colored(f"Cookie {self.cookie_hash[:10]} Đã Bị Ngưng Connect Vĩnh Viễn, Lí Do: Die Cookies, Check Point v.v", 'red'))
            return False
            
        current_time = time.time()
        if current_time < cookie_attempts[self.cookie_hash]['banned_until']:
            remaining = cookie_attempts[self.cookie_hash]['banned_until'] - current_time
            print(colored(f"Cookie {self.cookie_hash[:10]} Bị Tạm Khóa, Còn {remaining/3600:.1f} Giờ", 'yellow'))
            return False

        if not self.lastSeqID:
            print(colored("Error: No last_seq_id Available. Cannot Connect To MQTT.", 'red'))
            return False

        chat_on = json_minimal(True)
        session_id = generate_session_id()
        user = {
            "u": self.dataFB["FacebookID"],
            "s": session_id,
            "chat_on": chat_on,
            "fg": False,
            "d": generate_client_id(),
            "ct": "websocket",
            "aid": 219994525426954,
            "mqtt_sid": "",
            "cp": 3,
            "ecp": 10,
            "st": ["/t_ms", "/messenger_sync_get_diffs", "/messenger_sync_create_queue"],
            "pm": [],
            "dc": "",
            "no_auto_fg": True,
            "gas": None,
            "pack": [],
        }

        host = f"wss://edge-chat.messenger.com/chat?region=eag&sid={session_id}"
        options = {
            "client_id": "mqttwsclient",
            "username": json_minimal(user),
            "clean": True,
            "ws_options": {
                "headers": {
                    "Cookie": self.dataFB['cookieFacebook'],
                    "Origin": "https://www.messenger.com",
                    "User-Agent": "Mozilla/5.0 (Linux; Android 9; SM-G973U Build/PPR1.180610.011) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36",
                    "Referer": "https://www.messenger.com/",
                    "Host": "edge-chat.messenger.com",
                },
            },
            "keepalive": 10,
        }

        self.mqtt = mqtt.Client(
            client_id="mqttwsclient",
            clean_session=True,
            protocol=mqtt.MQTTv31,
            transport="websockets",
        )

        self.mqtt.tls_set(certfile=None, keyfile=None, cert_reqs=ssl.CERT_NONE, tls_version=ssl.PROTOCOL_TLSv1_2)
        self.mqtt.on_connect = self._messenger_queue_publish
        self.mqtt.on_disconnect = self.on_disconnect
        self.mqtt.username_pw_set(username=options["username"])

        parsed_host = urlparse(host)
        self.mqtt.ws_set_options(
            path=f"{parsed_host.path}?{parsed_host.query}",
            headers=options["ws_options"]["headers"],
        )

        print(colored(f"Connecting To {options['ws_options']['headers']['Host']}...", 'cyan'))
        try:
            self.mqtt.connect(
                host=options["ws_options"]["headers"]["Host"],
                port=443,
                keepalive=options["keepalive"],
            )

            print(colored("MQTT Connection Established", 'green'))
            self.mqtt.loop_start()
            return True
        except Exception as e:
            print(colored(f"MQTT Connection Error: {e}", 'red'))
            cookie_attempts[self.cookie_hash]['count'] += 1
            return False

    def stop(self):
        if self.mqtt:
            print(colored("Stopping MQTT Client...", 'yellow'))
            try:
                self.mqtt.disconnect()
                self.mqtt.loop_stop()
            except:
                pass
        self.cleanup_memory()

class Ctevcl:
    def __init__(self, cookie):
        import re
        self.cookie = cookie
        self.user_id = self.id_user()
        self.fb_dtsg = None
        self.jazoest = None
        self.rev = None
        self.init_params()

    def id_user(self):
        try:
            match = re.search(r"c_user=(\d+)", self.cookie)
            if not match:
                raise Exception("Cookie không hợp lệ")
            return match.group(1)
        except Exception as e:
            raise Exception(f"Lỗi khi lấy user_id: {str(e)}")

    def init_params(self):
        headers = {
            'Cookie': self.cookie,
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1'
        }
        urls = [
            'https://www.facebook.com',
            'https://mbasic.facebook.com',
            'https://m.facebook.com'
        ]

        for url in urls:
            try:
                print(colored(f"[*] Thử lấy fb_dtsg từ {url}", 'cyan'))
                response = requests.get(url, headers=headers, timeout=10)

                if response.status_code != 200:
                    print(colored(f"[❌] Yêu cầu tới {url} thất bại, mã trạng thái: {response.status_code}", 'red'))
                    continue

                fb_dtsg_patterns = [
                    r'"token":"(.*?)"',
                    r'name="fb_dtsg" value="(.*?)"',
                    r'"fb_dtsg":"(.*?)"',
                    r'fb_dtsg=([^&"]+)'
                ]
                jazoest_pattern = r'name="jazoest" value="(\d+)"'
                rev_pattern = r'"__rev":"(\d+)"'

                fb_dtsg = None
                for pattern in fb_dtsg_patterns:
                    match = re.search(pattern, response.text)
                    if match:
                        fb_dtsg = match.group(1)
                        break

                jazoest_match = re.search(jazoest_pattern, response.text)
                rev_match = re.search(rev_pattern, response.text)

                if fb_dtsg:
                    self.fb_dtsg = fb_dtsg
                    self.jazoest = jazoest_match.group(1) if jazoest_match else "22036"
                    self.rev = rev_match.group(1) if rev_match else "1015919737"
                    print(colored(f"[✓] Lấy được fb_dtsg: {self.fb_dtsg}, jazoest: {self.jazoest}, rev: {self.rev}", 'green'))
                    return
                else:
                    print(colored(f"[⚠] Không tìm thấy fb_dtsg trong {url}", 'yellow'))

            except Exception as e:
                print(colored(f"[❌] Lỗi khi truy cập {url}: {str(e)}", 'red'))
                time.sleep(2)

        raise Exception("Không thể lấy được fb_dtsg từ bất kỳ URL nào")

def input_cookies():

    cookie_list = []
    stt = 1
    while True:
        ck = input(colored(f"Nhập cookie {stt} (Ấn 'enter' để dừng nhập): ", 'yellow', attrs=['bold'])).strip()
        if ck.lower() in ['', 'enter']:
            if cookie_list:
                print(colored(f'Đã lưu {len(cookie_list)} cookie', 'green'))
                for i, c in enumerate(cookie_list, 1):
                    print(colored(f'  [{i}] {c[:30]}...', 'cyan'))
            else:
                print(colored('Không có cookie nào được lưu', 'yellow'))
            break
        if 'c_user=' in ck and 'xs=' in ck:
            cookie_list.append(ck)
            stt += 1
        else:
            print(colored("Cookie không hợp lệ, vui lòng nhập lại", 'red'))
    return cookie_list

def input_thread_ids():

    id_list = []
    stt = 1
    while True:
        thread_id = input(colored(f"Nhập ID Box {stt} (Ấn 'enter' để dừng nhập): ", 'yellow', attrs=['bold'])).strip()
        if thread_id.lower() in ['', 'enter']:
            if id_list:
                print(colored(f'Đã lưu {len(id_list)} ID Box', 'green'))
                for id_ in id_list:
                    print(colored(f'  {id_}', 'cyan'))
            break
        if thread_id.isdigit():
            id_list.append(thread_id)
            stt += 1
        else:
            print(colored("ID Box phải là số, vui lòng nhập lại", 'red'))
    return id_list

def input_delay():

    while True:
        try:
            delay = int(input(colored('Nhập delay (giây): ', 'yellow', attrs=['bold'])).strip())
            if delay >= 0:
                return delay
            else:
                print(colored("Delay phải >= 0", 'red'))
        except ValueError:
            print(colored("Vui lòng nhập số", 'red'))

def change_themes(cookies, thread_ids, delay):
    global cookie_attempts, active_threads
    
    for cookie in cookies:
        cookie_hash = hashlib.md5(cookie.encode()).hexdigest()
        
        if cookie_attempts[cookie_hash]['permanent_ban']:
            print(colored(f"Cookie {cookie_hash[:10]} Đã Bị Ngưng Hoạt Động Vĩnh Viễn\nLí Do: Cookies Die, CheckPoint V.V", 'red'))
            continue
            
        current_time = time.time()
        if current_time < cookie_attempts[cookie_hash]['banned_until']:
            remaining = cookie_attempts[cookie_hash]['banned_until'] - current_time
            print(colored(f"Cookie {cookie_hash[:10]} Bị Tạm Khóa, Còn {remaining/3600:.1f} Giờ\nLí Do: Checkpoint, Mõm, Cookies Die", 'yellow'))
            continue

        try:
            fb = Ctevcl(cookie)
            changer = ThemeChanger(fbTools({
                "FacebookID": fb.user_id,
                "fb_dtsg": fb.fb_dtsg,
                "clientRevision": fb.rev,
                "jazoest": fb.jazoest,
                "cookieFacebook": cookie
            }), {
                "FacebookID": fb.user_id,
                "fb_dtsg": fb.fb_dtsg,
                "clientRevision": fb.rev,
                "jazoest": fb.jazoest,
                "cookieFacebook": cookie
            }, fb)

            changer.get_last_seq_id()
            if not changer.connect_mqtt():
                handle_failed_connection(cookie_hash)
                continue

            for thread_id in thread_ids:
                print(colored(f"Bắt Đầu Xử Lý Thay Đổi Theme Cho Box: {thread_id} với Cookie: {cookie_hash[:10]}", 'cyan', attrs=['bold']))
                
                active_threads[f"{cookie_hash}_{thread_id}"] = changer

                try:
                    themes = changer.THEMES
                    if not themes:
                        print(colored("[!] Danh sách theme rỗng!", 'yellow'))
                        break
                    theme_index = 0
                    while True:
                        theme = themes[theme_index % len(themes)]
                        theme_id = theme["id"]
                        theme_name = theme["name"]
                        print(colored(f"[*] Thay đổi theme với ID: {theme_id} ({theme_name}) cho box {thread_id}", 'cyan'))
                        success = changer.set_theme(theme_id, thread_id)
                        if success:
                            print(colored(f"[✓] Đã thay đổi theme thành: {theme_name} (ID: {theme_id}) cho box {thread_id}", 'green'))
                        else:
                            print(colored(f"[❌] Thay đổi theme thất bại cho box {thread_id}", 'red'))
                        theme_index += 1
                        time.sleep(delay)
                        if time.time() - changer.last_cleanup > 600:
                            gc.collect()

                except KeyboardInterrupt:
                    print(colored(f"\nDừng Xử Lý Theme Cho Box: {thread_id}", 'yellow'))
                    break
                finally:
                    changer.stop()
                    if f"{cookie_hash}_{thread_id}" in active_threads:
                        del active_threads[f"{cookie_hash}_{thread_id}"]

        except Exception as e:
            print(colored(f"Lỗi Trong Luồng Xử Lý Với Cookie {cookie_hash[:10]}: {e}", 'red'))
            handle_failed_connection(cookie_hash)
            continue

    return True

def treo_theme():
    clear()
    banner()
    
    print(colored("\n[NHẬP COOKIE]", 'magenta', attrs=['bold']))
    cookies = input_cookies()
    if not cookies:
        print(colored("Không có cookie nào, thoát chương trình", 'red'))
        return
        
    print(colored("\n[NHẬP ID BOX]", 'magenta', attrs=['bold']))
    thread_ids = input_thread_ids()
    if not thread_ids:
        print(colored("Không có ID box nào, thoát chương trình", 'red'))
        return
        
    print(colored("\n[NHẬP DELAY]", 'magenta', attrs=['bold']))
    delay = input_delay()
    
    # Xác nhận
    print("\n" + "=" * 60)
    print(colored(f"Tổng số cookie: {len(cookies)}", 'cyan', attrs=['bold']))
    print(colored(f"Tổng số ID box: {len(thread_ids)}", 'cyan', attrs=['bold']))
    print(colored(f"Delay: {delay} giây", 'cyan', attrs=['bold']))
    print("=" * 60)
    
    confirm = input(colored("\nBắt đầu thay đổi theme? (y/n): ", 'yellow', attrs=['bold'])).strip().lower()
    if confirm != 'y':
        print(colored("Đã hủy", 'red'))
        return
        
    print(colored(f"\n[*] Bắt đầu thay đổi theme cho {len(thread_ids)} box với {len(cookies)} cookie, delay {delay}s...", 'green', attrs=['bold']))
    print(colored("[*] Nhấn Ctrl+C để dừng chương trình\n", 'yellow'))
    
    change_themes(cookies, thread_ids, delay)

if __name__ == "__main__":
    try:
        treo_theme()
    except KeyboardInterrupt:
        print(colored("\n[*] Dừng chương trình.", 'yellow'))
    except Exception as e:
        print(colored(f"[!] Lỗi: {str(e)}", 'red'))