#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Chức năng: Reg Box Messenger - Tạo nhóm chat mới trên Facebook Messenger
Tách từ file allchucnang.py - Chức năng số 6
"""

import os
import sys
import time
import json
import random
import hashlib
import re
from urllib.parse import urlparse, urlencode
from datetime import datetime
import requests

# Global variables for cookie management
cookie_attempts = {}
cookie_delays = {}
active_threads = {}

def handle_failed_connection(cookie_hash):
    """Handle failed connection attempts for a cookie"""
    global cookie_attempts
    
    current_time = time.time()
    
    if cookie_hash not in cookie_attempts:
        cookie_attempts[cookie_hash] = {'count': 0, 'last_reset': current_time, 'banned_until': 0, 'permanent_ban': False}
    
    if current_time - cookie_attempts[cookie_hash]['last_reset'] > 43200:
        cookie_attempts[cookie_hash]['count'] = 0
        cookie_attempts[cookie_hash]['last_reset'] = current_time
        cookie_attempts[cookie_hash]['banned_until'] = 0
    
    if cookie_attempts[cookie_hash]['banned_until'] > 0:
        ban_count = cookie_attempts[cookie_hash].get('ban_count', 0) + 1
        cookie_attempts[cookie_hash]['ban_count'] = ban_count
        
        if ban_count >= 5:
            cookie_attempts[cookie_hash]['permanent_ban'] = True
            print(f"Cookie {cookie_hash[:10]} Đã Bị Ngưng Hoạt Động Vĩnh Viễn Để Tránh Đầy Memory, Lí Do: Acc Die, CheckPoint v.v")

def parse_cookie_string(cookie_string):
    """Parse cookie string into dictionary"""
    cookie_dict = {}
    cookies = cookie_string.split(";")
    for cookie in cookies:
        if "=" in cookie:
            key, value = cookie.strip().split("=", 1)
            cookie_dict[key] = value
    return cookie_dict

def get_headers(url: str, options: dict = {}, ctx: dict = {}, customHeader: dict = {}) -> dict:
    """Generate headers for requests"""
    headers = {
        "Accept-Encoding": "gzip, deflate",
        "Content-Type": "application/x-www-form-urlencoded",
        "Referer": "https://www.facebook.com/",
        "Host": urlparse(url).netloc,
        "Origin": "https://www.facebook.com",
        "User-Agent": "Mozilla/5.0 (Linux; Android 9; SM-G973U Build/PPR1.180610.011) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36",
        "Connection": "keep-alive",
    }

    if "user_agent" in options:
        headers["User-Agent"] = options["user_agent"]

    for key in customHeader:
        headers[key] = customHeader[key]

    if "region" in ctx:
        headers["X-MSGR-Region"] = ctx["region"]

    return headers

def read_cookies_from_file(file_path):
    """Read cookies from a file, one cookie per line."""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            cookies = [line.strip() for line in f if line.strip()]
        if not cookies:
            raise ValueError("File cookie rỗng hoặc không có cookie hợp lệ.")
        return cookies
    except FileNotFoundError:
        raise FileNotFoundError(f"File không tồn tại: {file_path}")
    except Exception as e:
        raise Exception(f"Lỗi khi đọc file cookie: {str(e)}")

class Counter:
    """Simple counter class"""
    def __init__(self, initial_value=0):
        self.value = initial_value
        
    def increment(self):
        self.value += 1
        return self.value
        
    @property
    def counter(self):
        return self.value

def digitToChar(digit):
    """Convert digit to character for base conversion"""
    if digit < 10:
        return str(digit)
    return chr(ord('a') + digit - 10)

def str_base(number, base):
    """Convert number to string in given base"""
    if number < 0:
        return "-" + str_base(-number, base)
    (d, m) = divmod(number, base)
    if d > 0:
        return str_base(d, base) + digitToChar(m)
    return digitToChar(m)

def generate_offline_threading_id() -> str:
    """Generate offline threading ID for Facebook requests"""
    ret = int(time.time() * 1000)
    value = random.randint(0, 4294967295)
    binary_str = format(value, "022b")[-22:]
    msgs = bin(ret)[2:] + binary_str
    return str(int(msgs, 2))

class minhloi:
    """Main class for Facebook interaction"""
    def __init__(self, cookie):
        self.cookie = cookie
        self.user_id = self.id_user()
        self.fb_dtsg = None
        self.jazoest = None
        self.rev = None
        self.init_params()

    def id_user(self):
        """Extract user ID from cookie"""
        try:
            match = re.search(r"c_user=(\d+)", self.cookie)
            if not match:
                raise Exception("Cookie không hợp lệ")
            return match.group(1)
        except Exception as e:
            raise Exception(f"Lỗi khi lấy user_id: {str(e)}")

    def init_params(self):
        """Initialize Facebook parameters (fb_dtsg, jazoest, rev)"""
        headers = {
            'Cookie': self.cookie,
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1'
        }
        urls = [
            'https://www.facebook.com',
            'https://mbasic.facebook.com',
            'https://m.facebook.com'
        ]

        for url in urls:
            try:
                print(f"[*] Thử lấy fb_dtsg từ {url}")
                response = requests.get(url, headers=headers, timeout=10)

                if response.status_code != 200:
                    print(f"[❌] Yêu cầu tới {url} thất bại, mã trạng thái: {response.status_code}")
                    continue

                # Save debug HTML
                with open('response_debug.html', 'w', encoding='utf-8') as f:
                    f.write(response.text)
#                print(f"[*] Đã lưu phản hồi HTML vào response_debug.html để kiểm tra")

                # Patterns to extract fb_dtsg
                fb_dtsg_patterns = [
                    r'"token":"(.*?)"',
                    r'name="fb_dtsg" value="(.*?)"',
                    r'"fb_dtsg":"(.*?)"',
                    r'fb_dtsg=([^&"]+)'
                ]
                jazoest_pattern = r'name="jazoest" value="(\d+)"'
                rev_pattern = r'"__rev":"(\d+)"'

                fb_dtsg = None
                for pattern in fb_dtsg_patterns:
                    match = re.search(pattern, response.text)
                    if match:
                        fb_dtsg = match.group(1)
                        break

                jazoest_match = re.search(jazoest_pattern, response.text)
                rev_match = re.search(rev_pattern, response.text)

                if fb_dtsg:
                    self.fb_dtsg = fb_dtsg
                    self.jazoest = jazoest_match.group(1) if jazoest_match else "22036"
                    self.rev = rev_match.group(1) if rev_match else "1015919737"
                    print(f"[✓] Lấy được fb_dtsg: {self.fb_dtsg}, jazoest: {self.jazoest}, rev: {self.rev}")
                    return
                else:
                    print(f"[⚠] Không tìm thấy fb_dtsg trong {url}")

            except Exception as e:
                print(f"[❌] Lỗi khi truy cập {url}: {str(e)}")
                time.sleep(2)

        raise Exception("Không thể lấy được fb_dtsg từ bất kỳ URL nào")

def create_new_group(dataFB, participant_ids, group_title):
    """Create a new Facebook group with the given participants and title."""
    try:
        if not isinstance(participant_ids, list):
            raise ValueError("participant_ids should be an array.")
        
        if len(participant_ids) < 2:
            raise ValueError("participant_ids should have at least 2 IDs.")

        # Initialize counter for request ID
        _req_counter = Counter(0)
        
        pids = [{"fbid": str(pid)} for pid in participant_ids]
        pids.append({"fbid": str(dataFB["FacebookID"])})

        form = {
            "fb_api_caller_class": "RelayModern",
            "fb_api_req_friendly_name": "MessengerGroupCreateMutation",
            "av": str(dataFB["FacebookID"]),
            "doc_id": "577041672419534",
            "variables": json.dumps({
                "input": {
                    "entry_point": "jewel_new_group",
                    "actor_id": str(dataFB["FacebookID"]),
                    "participants": pids,
                    "client_mutation_id": str(random.randint(1, 1024)),
                    "thread_settings": {
                        "name": group_title,
                        "joinable_mode": "PRIVATE",
                        "thread_image_fbid": None
                    }
                }
            }, separators=(",", ":")),
            "fb_dtsg": dataFB["fb_dtsg"],
            "jazoest": dataFB["jazoest"],
            "__user": str(dataFB["FacebookID"]),
            "__a": "1",
            "__req": str_base(_req_counter.increment(), 36),
            "__rev": dataFB.get("clientRevision", "1015919737")
        }

        headers = get_headers("https://www.facebook.com/api/graphql/", customHeader={
            "Content-Type": "application/x-www-form-urlencoded"
        })

        print(f"[*] Đang tạo nhóm: {group_title}...")
        response = requests.post(
            "https://www.facebook.com/api/graphql/",
            data=form,
            headers=headers,
            cookies=parse_cookie_string(dataFB["cookieFacebook"]),
            timeout=15
        )

        if response.status_code != 200:
            raise Exception(f"HTTP Error {response.status_code}")

        # Remove for (;;); prefix if present
        content = response.text
        if content.startswith('for (;;);'):
            content = content[9:]
        
        try:
            data = json.loads(content)
        except json.JSONDecodeError as e:
            # Save response for debugging
            with open('error_response.json', 'w', encoding='utf-8') as f:
                f.write(content)
            raise Exception(f"JSON Decode Error: {e}. Response saved to error_response.json")

        if "errors" in data:
            error_msg = data['errors'][0]['message'] if data['errors'] else "Unknown error"
            raise Exception(f"API Error: {error_msg}")

        if "data" not in data or "messenger_group_thread_create" not in data["data"]:
            raise Exception("Unexpected response structure")

        thread_id = data["data"]["messenger_group_thread_create"]["thread"]["thread_key"]["thread_fbid"]
        return True, thread_id, f"✅ [{datetime.now().strftime('%H:%M:%S')}] Đã tạo nhóm: {group_title} (ID: {thread_id})"
    
    except Exception as e:
        return False, None, f"❌ [{datetime.now().strftime('%H:%M:%S')}] Lỗi khi tạo nhóm {group_title}: {str(e)}"

def main():
    """Main function for Reg Box Messenger functionality"""
    try:
        print("=" * 60)
        print("           CHỨC NĂNG REG BOX MESSENGER")
        print("=" * 60)
        print()

        # Get cookie file
        cookie_file = input("[+] Nhập đường dẫn file chứa cookie (mỗi cookie 1 dòng):\n> ").strip()
        
        if not os.path.isfile(cookie_file):
            print(f"[!] File không tồn tại: {cookie_file}")
            input("\nNhấn Enter để thoát...")
            return

        # Read cookies
        try:
            cookies = read_cookies_from_file(cookie_file)
            print(f"[*] Đã đọc {len(cookies)} cookie từ file.")
        except Exception as e:
            print(f"[!] Lỗi đọc file cookie: {str(e)}")
            input("\nNhấn Enter để thoát...")
            return

        # Get number of groups to create
        try:
            num_groups = int(input("\n[+] Nhập số lượng nhóm muốn tạo cho mỗi cookie:\n> ").strip())
            if num_groups <= 0:
                print("[!] Số lượng nhóm phải lớn hơn 0")
                input("\nNhấn Enter để thoát...")
                return
        except ValueError:
            print("[!] Vui lòng nhập số hợp lệ")
            input("\nNhấn Enter để thoát...")
            return

        # Get base group name
        base_group_name = input("\n[+] Nhập tên cơ bản cho nhóm (ví dụ: 'kaka' sẽ tạo 'kaka 1', 'kaka 2', ...):\n> ").strip()
        if not base_group_name:
            base_group_name = "Group"
            print(f"[*] Sử dụng tên mặc định: {base_group_name}")

        # Get user IDs to add
        user_ids_input = input("\n[+] Nhập danh sách ID người cần thêm vào nhóm (cách nhau bởi dấu phẩy):\n> ").strip()
        user_ids = [uid.strip() for uid in user_ids_input.split(",") if uid.strip()]
        
        if len(user_ids) < 2:
            print("[!] Cần ít nhất 2 ID để tạo nhóm (không tính chủ nhóm).")
            input("\nNhấn Enter để thoát...")
            return

        print(f"\n[*] Danh sách ID sẽ được thêm: {', '.join(user_ids)}")
        print(f"[*] Mỗi cookie sẽ tạo {num_groups} nhóm với tên '{base_group_name} 1' đến '{base_group_name} {num_groups}'")
        
        confirm = 'y'
        if confirm != 'y':
            print("[*] Đã hủy thao tác.")
            input("\nNhấn Enter để thoát...")
            return

        print("\n" + "=" * 60)
        print("           BẮT ĐẦU TẠO NHÓM")
        print("=" * 60 + "\n")

        total_groups_created = 0
        total_groups_failed = 0

        # Process each cookie
        for cookie_index, cookie in enumerate(cookies, 1):
            cookie_hash = hashlib.md5(cookie.encode()).hexdigest()
            
            print(f"\n--- ĐANG XỬ LÝ COOKIE {cookie_index}/{len(cookies)} (Hash: {cookie_hash[:10]}) ---")
            
            # Check if cookie is permanently banned
            if cookie_hash in cookie_attempts and cookie_attempts[cookie_hash].get('permanent_ban', False):
                print(f"❌ Cookie {cookie_hash[:10]} Đã Bị Ngưng Hoạt Động Vĩnh Viễn")
                print("   Lí Do: Cookies Die, CheckPoint V.V")
                continue
            
            # Check if cookie is temporarily banned
            current_time = time.time()
            if cookie_hash in cookie_attempts and current_time < cookie_attempts[cookie_hash].get('banned_until', 0):
                remaining = cookie_attempts[cookie_hash]['banned_until'] - current_time
                print(f"⚠ Cookie {cookie_hash[:10]} Bị Tạm Khóa, Còn {remaining/3600:.1f} Giờ")
                print("   Lí Do: Checkpoint, Mõm, Cookies Die")
                continue

            try:
                # Initialize Facebook connection
                print(f"[*] Đang khởi tạo kết nối cho cookie {cookie_index}...")
                fb = minhloi(cookie)
                
                dataFB = {
                    "FacebookID": fb.user_id,
                    "fb_dtsg": fb.fb_dtsg,
                    "clientRevision": fb.rev,
                    "jazoest": fb.jazoest,
                    "cookieFacebook": cookie
                }
                
                print(f"[✓] Đăng nhập thành công với UID: {fb.user_id}")
                
                # Create groups for this cookie
                groups_created = 0
                groups_failed = 0
                
                for i in range(num_groups):
                    group_title = f"{base_group_name} {i+1}"
                    print(f"\n[*] Đang tạo nhóm {i+1}/{num_groups}: {group_title}")
                    
                    # Add random delay between group creations
                    if i > 0:
                        delay = random.uniform(2, 5)
                        print(f"[*] Chờ {delay:.1f} giây...")
                        time.sleep(delay)
                    
                    success, thread_id, log = create_new_group(dataFB, user_ids, group_title)
                    print(log)
                    
                    if success:
                        groups_created += 1
                        total_groups_created += 1
                    else:
                        groups_failed += 1
                        total_groups_failed += 1
                        
                        # If failed due to cookie issue, mark it
                        if "checkpoint" in log.lower() or "die" in log.lower():
                            handle_failed_connection(cookie_hash)
                            break
                
                print(f"\n--- KẾT QUẢ CHO COOKIE {cookie_index} ---")
                print(f"✅ Tạo thành công: {groups_created} nhóm")
                print(f"❌ Thất bại: {groups_failed} nhóm")
                
            except Exception as e:
                print(f"❌ Lỗi khi xử lý cookie {cookie_index}: {str(e)}")
                handle_failed_connection(cookie_hash)
                continue
            
            # Add delay between cookies
            if cookie_index < len(cookies):
                delay = random.uniform(3, 7)
                print(f"\n[*] Chờ {delay:.1f} giây trước khi xử lý cookie tiếp theo...")
                time.sleep(delay)
        
        # Final summary
        print("\n" + "=" * 60)
        print("           KẾT QUẢ TỔNG KẾT")
        print("=" * 60)
        print(f"✅ Tổng số nhóm tạo thành công: {total_groups_created}")
        print(f"❌ Tổng số nhóm thất bại: {total_groups_failed}")
        print(f"📊 Tổng số cookie đã xử lý: {len(cookies)}")
        print("=" * 60)

    except KeyboardInterrupt:
        print("\n\n[*] Đã dừng chương trình bởi người dùng.")
    except Exception as e:
        print(f"\n[!] Lỗi không mong muốn: {str(e)}")
    finally:
        print("\n" + "=" * 60)
        input("Nhấn Enter để thoát...")

if __name__ == "__main__":
    main()