import discord
from discord.ext import commands
import asyncio

print("==== TOOL TẠO KÊNH CHAT DISCORD ====")
TOKEN = input("Nhập Bot Token: ").strip()
PREFIX = input("Nhập Prefix (ví dụ !): ").strip()

intents = discord.Intents.default()
intents.message_content = True
intents.guilds = True

bot = commands.Bot(command_prefix=PREFIX, intents=intents)


@bot.event
async def on_ready():
    print(f"Bot đã đăng nhập: {bot.user}")
    print("====================================")


@bot.command()
@commands.has_permissions(administrator=True)
async def create(ctx):
    def check(m):
        return m.author == ctx.author and m.channel == ctx.channel

    embed = discord.Embed(
        title="📌 TẠO KÊNH MỚI",
        description="Chọn loại kênh bạn muốn tạo:\n\n"
                    "1️⃣ Text Channel\n"
                    "2️⃣ Voice Channel\n"
                    "3️⃣ Forum Channel\n\n"
                    "👉 Nhập số (1 / 2 / 3)",
        color=discord.Color.blue()
    )
    embed.set_footer(text=f"Yêu cầu bởi {ctx.author}")
    await ctx.send(embed=embed)

    try:
        msg_type = await bot.wait_for("message", timeout=60, check=check)
    except asyncio.TimeoutError:
        return await ctx.send("⏰ Hết thời gian nhập.")

    channel_type = msg_type.content.strip()

    if channel_type not in ["1", "2", "3"]:
        return await ctx.send("❌ Lựa chọn không hợp lệ.")

    await ctx.send("✏ Nhập tên kênh bạn muốn tạo:")

    try:
        msg_name = await bot.wait_for("message", timeout=60, check=check)
    except asyncio.TimeoutError:
        return await ctx.send("⏰ Hết thời gian nhập.")

    channel_name = msg_name.content.strip()
    guild = ctx.guild

    try:
        if channel_type == "1":
            channel = await guild.create_text_channel(channel_name)
            msg = f"🎉 {ctx.author.mention} đã tạo Text Channel: {channel.mention}"

        elif channel_type == "2":
            channel = await guild.create_voice_channel(channel_name)
            msg = f"🎉 {ctx.author.mention} đã tạo Voice Channel: **{channel.name}**"

        elif channel_type == "3":
            channel = await guild.create_forum(name=channel_name)
            msg = f"🎉 {ctx.author.mention} đã tạo Forum Channel: {channel.mention}"

        success_embed = discord.Embed(
            title="✅ TẠO KÊNH THÀNH CÔNG",
            description=msg,
            color=discord.Color.green()
        )

        await ctx.send(embed=success_embed)

    except Exception as e:
        await ctx.send(f"❌ Có lỗi xảy ra: {e}")


@create.error
async def create_error(ctx, error):
    if isinstance(error, commands.MissingPermissions):
        await ctx.send("❌ Bạn cần quyền Administrator để dùng lệnh này.")
    else:
        await ctx.send(f"❌ Lỗi: {error}")


bot.run(TOKEN)