import json
import time
import requests
import os
import re
from datetime import datetime
from urllib.parse import urlparse
import random

def parse_cookie_string(cookie_string):
    cookie_dict = {}
    cookies = cookie_string.split(";")
    for cookie in cookies:
        if "=" in cookie:
            key, value = cookie.strip().split("=", 1)
            cookie_dict[key] = value
    return cookie_dict

def get_headers(url, options={}, ctx={}, customHeader={}):
    headers = {
        "Accept-Encoding": "gzip, deflate",
        "Content-Type": "application/x-www-form-urlencoded",
        "Referer": "https://www.facebook.com/",
        "Host": urlparse(url).netloc,
        "Origin": "https://www.facebook.com",
        "User-Agent": "Mozilla/5.0 (Linux; Android 9; SM-G973U Build/PPR1.180610.011) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36",
        "Connection": "keep-alive",
    }
    if "user_agent" in options:
        headers["User-Agent"] = options["user_agent"]
    for key in customHeader:
        headers[key] = customHeader[key]
    if "region" in ctx:
        headers["X-MSGR-Region"] = ctx["region"]
    return headers

class Counter:
    def __init__(self, initial_value=0):
        self.value = initial_value
        
    def increment(self):
        self.value += 1
        return self.value
        
    @property
    def counter(self):
        return self.value

def digitToChar(digit):
    if digit < 10:
        return str(digit)
    return chr(ord('a') + digit - 10)

def str_base(number, base):
    if number < 0:
        return "-" + str_base(-number, base)
    (d, m) = divmod(number, base)
    if d > 0:
        return str_base(d, base) + digitToChar(m)
    return digitToChar(m)

def formAll(dataFB, FBApiReqFriendlyName=None, docID=None, requireGraphql=None):
    global _req_counter
    if '_req_counter' not in globals():
        _req_counter = Counter(0)
    
    __reg = _req_counter.increment()
    dataForm = {}
    
    if requireGraphql is None:
        dataForm["fb_dtsg"] = dataFB["fb_dtsg"]
        dataForm["jazoest"] = dataFB["jazoest"]
        dataForm["__a"] = 1
        dataForm["__user"] = str(dataFB["FacebookID"])
        dataForm["__req"] = str_base(__reg, 36) 
        dataForm["__rev"] = dataFB["clientRevision"]
        dataForm["av"] = dataFB["FacebookID"]
        dataForm["fb_api_caller_class"] = "RelayModern"
        dataForm["fb_api_req_friendly_name"] = FBApiReqFriendlyName
        dataForm["server_timestamps"] = "true"
        dataForm["doc_id"] = str(docID)
    else:
        dataForm["fb_dtsg"] = dataFB["fb_dtsg"]
        dataForm["jazoest"] = dataFB["jazoest"]
        dataForm["__a"] = 1
        dataForm["__user"] = str(dataFB["FacebookID"])
        dataForm["__req"] = str_base(__reg, 36) 
        dataForm["__rev"] = dataFB["clientRevision"]
        dataForm["av"] = dataFB["FacebookID"]
    return dataForm

def mainRequests(url, data, cookies):
    return {
        "url": url,
        "data": data,
        "headers": {
            "authority": "www.facebook.com",
            "accept": "*/*",
            "accept-language": "en-US,en;q=0.9,vi;q=0.8",
            "content-type": "application/x-www-form-urlencoded",
            "origin": "https://www.facebook.com",
            "referer": "https://www.facebook.com/",
            "sec-ch-ua": "\"Not?A_Brand\";v=\"8\", \"Chromium\";v=\"108\"",
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": "\"Windows\"",
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-origin",
            "user-agent": "Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36",
            "x-fb-friendly-name": "FriendingCometFriendRequestsRootQueryRelayPreloader",
            "x-fb-lsd": "YCb7tYCGWDI6JLU5Aexa1-"
        },
        "cookies": parse_cookie_string(cookies),
        "verify": True
    }

class minhloi:
    def __init__(self, cookie):
        self.cookie = cookie
        self.user_id = self.id_user()
        self.fb_dtsg = None
        self.jazoest = None
        self.rev = None
        self.init_params()

    def id_user(self):
        try:
            match = re.search(r"c_user=(\d+)", self.cookie)
            if not match:
                raise Exception("Cookie không hợp lệ")
            return match.group(1)
        except Exception as e:
            raise Exception(f"Lỗi khi lấy user_id: {str(e)}")

    def init_params(self):
        headers = {
            'Cookie': self.cookie,
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1'
        }
        urls = [
            'https://www.facebook.com',
            'https://mbasic.facebook.com',
            'https://m.facebook.com'
        ]
        for url in urls:
            try:
                response = requests.get(url, headers=headers, timeout=10)
                if response.status_code != 200:
                    continue
                fb_dtsg_patterns = [
                    r'"token":"(.*?)"',
                    r'name="fb_dtsg" value="(.*?)"',
                    r'"fb_dtsg":"(.*?)"',
                    r'fb_dtsg=([^&"]+)'
                ]
                jazoest_pattern = r'name="jazoest" value="(\d+)"'
                rev_pattern = r'"__rev":"(\d+)"'
                fb_dtsg = None
                for pattern in fb_dtsg_patterns:
                    match = re.search(pattern, response.text)
                    if match:
                        fb_dtsg = match.group(1)
                        break
                jazoest_match = re.search(jazoest_pattern, response.text)
                rev_match = re.search(rev_pattern, response.text)
                if fb_dtsg:
                    self.fb_dtsg = fb_dtsg
                    self.jazoest = jazoest_match.group(1) if jazoest_match else "22036"
                    self.rev = rev_match.group(1) if rev_match else "1015919737"
                    return
            except Exception:
                time.sleep(2)
        raise Exception("Không thể lấy được fb_dtsg từ bất kỳ URL nào")

def get_messages(cookie, thread_id):
    try:
        fb = minhloi(cookie)
        data = {
            "FacebookID": fb.user_id,
            "fb_dtsg": fb.fb_dtsg,
            "clientRevision": fb.rev,
            "jazoest": fb.jazoest,
            "cookieFacebook": cookie
        }
        dataForm = formAll(data, "ThreadQuery", "6625240927508328")
        dataForm["variables"] = json.dumps({
            "threadID": thread_id,
            "count": 100
        })
        response = requests.post(**mainRequests("https://www.facebook.com/api/graphql/", dataForm, cookie))
        if response.status_code == 200:
            response_data = json.loads(response.text[9:] if response.text.startswith("for(;;);") else response.text)
            messages = response_data.get("data", {}).get("thread", {}).get("messages", {}).get("nodes", [])
            return [msg["message_id"] for msg in messages]
        return []
    except Exception as e:
        print(f"Lỗi khi lấy danh sách tin nhắn: {str(e)}")
        return []

def delete_message(cookie, thread_id, message_id):
    try:
        fb = minhloi(cookie)
        data = {
            "FacebookID": fb.user_id,
            "fb_dtsg": fb.fb_dtsg,
            "clientRevision": fb.rev,
            "jazoest": fb.jazoest,
            "cookieFacebook": cookie
        }
        dataForm = formAll(data, "MessageDeleteMutation", "6220733874683730")
        dataForm["variables"] = json.dumps({
            "input": {
                "message_ids": [message_id],
                "thread_key": {"thread_fbid": thread_id},
                "client_mutation_id": str(random.randint(1, 1000000))
            }
        })
        response = requests.post(**mainRequests("https://www.facebook.com/api/graphql/", dataForm, cookie))
        if response.status_code == 200:
            return True
        return False
    except Exception as e:
        print(f"Lỗi khi xóa tin nhắn: {str(e)}")
        return False

def delete_all_messages(cookie, thread_id):
    try:
        message_ids = get_messages(cookie, thread_id)
        if not message_ids:
            print(f"[!] Không tìm thấy tin nhắn trong box {thread_id}")
            return False
        success_count = 0
        for message_id in message_ids:
            if delete_message(cookie, thread_id, message_id):
                success_count += 1
                print(f"[✓] Đã xóa tin nhắn {message_id}")
            else:
                print(f"[❌] Xóa tin nhắn {message_id} thất bại")
            time.sleep(1)
        print(f"[*] Đã xóa {success_count}/{len(message_ids)} tin nhắn")
        return success_count > 0
    except Exception as e:
        print(f"Lỗi khi xóa tất cả tin nhắn: {str(e)}")
        return False

def read_cookies_from_file(file_path):
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            cookies = [line.strip() for line in f if line.strip()]
        if not cookies:
            raise ValueError("File cookie rỗng hoặc không có cookie hợp lệ.")
        return cookies
    except FileNotFoundError:
        raise FileNotFoundError(f"File không tồn tại: {file_path}")
    except Exception as e:
        raise Exception(f"Lỗi khi đọc file cookie: {str(e)}")

if __name__ == "__main__":
    try:
        cookie_file = input("[+] Nhập đường dẫn file chứa cookie (mỗi cookie 1 dòng):\n> ").strip()
        thread_id = input("[+] Nhập ID box:\n> ").strip()
        if not os.path.isfile(cookie_file):
            print(f"[!] File cookie không tồn tại: {cookie_file}")
            exit()
        cookies = read_cookies_from_file(cookie_file)
        print(f"[*] Đã đọc {len(cookies)} cookie từ file.")
        for cookie in cookies:
            print(f"[*] Xóa tất cả tin nhắn trong box {thread_id}")
            success = delete_all_messages(cookie, thread_id)
            if success:
                print(f"[✓] Đã xóa tất cả tin nhắn trong box {thread_id}")
            else:
                print(f"[❌] Xóa tất cả tin nhắn thất bại")
    except KeyboardInterrupt:
        print("\n[*] Dừng chương trình.")
    except Exception as e:
        print(f"[!] Lỗi: {str(e)}")