import os
import requests
from zlapi.models import Message

des = {
    'version': "1.0.0",
    'credits': "Phạm Gia Long",
    'description': "Xem thông tin Free Fire theo UID",
    'power': "Thành Viên"
}

API_INFO = "https://huutri.id.vn/api/freefire/info?uid={}"

def log_info(text):
    return text

def lay_thong_tin(uid):
    try:
        url = API_INFO.format(uid)
        response = requests.get(url)
        data = response.json()
        basic = data.get("basicInfo", {})
        credit = data.get("creditScoreInfo", {})
        pet = data.get("petInfo", {})
        social = data.get("socialInfo", {})

        msg = []
        msg.append("===== THÔNG TIN TÀI KHOẢN FREE FIRE =====")
        msg.append(f"UID: {data.get('uid')}")
        msg.append(f"Tên Nhân Vật: {basic.get('nickname')}")
        msg.append(f"Cấp Độ: {basic.get('level')}")
        msg.append(f"Kinh Nghiệm: {basic.get('exp')}")
        msg.append(f"Huy Hiệu Mùa Này: {basic.get('badgeCnt')} cái")
        msg.append(f"Like: {basic.get('liked')}")
        msg.append(f"Rank: {basic.get('rank')} | Điểm Rank: {basic.get('rankingPoints')}")
        msg.append(f"Rank CS: {basic.get('csRank')} | Điểm CS: {basic.get('csRankingPoints')}")
        msg.append(f"Phiên Bản: {basic.get('releaseVersion')}")
        msg.append(f"Vùng: {basic.get('region')}")

        if credit:
            msg.append("===== CREDIT SCORE =====")
            msg.append(f"Điểm Uy Tín: {credit.get('creditScore')}")
            msg.append(f"Tình Trạng: {credit.get('rewardState')}")

        if pet:
            msg.append("===== PET =====")
            msg.append(f"Pet ID: {pet.get('id')}")
            msg.append(f"Cấp Độ Pet: {pet.get('level')}")
            msg.append(f"EXP Pet: {pet.get('exp')}")

        if social:
            msg.append("===== SOCIAL =====")
            msg.append(f"Ngôn Ngữ: {social.get('language')}")
            msg.append(f"Tiểu sử: {social.get('signature')}")

        msg.append("===== HOÀN TẤT =====")
        return "\n".join(msg)
    except Exception as e:
        return f"Lỗi khi lấy thông tin: {str(e)}"

def handle_ffinfo_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.split()

    if len(parts) < 2:
        # Nếu người dùng không nhập UID
        error_message = Message(text="Vui lòng nhập UID người chơi.\nVí dụ: ffinfo 12345678")
        client.replyMessage(error_message, message_object, thread_id, thread_type)
        return

    uid = parts[1].strip()
    info_text = lay_thong_tin(uid)
    response_message = Message(text=info_text)
    client.replyMessage(response_message, message_object, thread_id, thread_type)

def TQuan():
    return {
        'ffinfo': handle_ffinfo_command
    }
