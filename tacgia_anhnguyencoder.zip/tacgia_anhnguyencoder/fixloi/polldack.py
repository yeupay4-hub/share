import os
import json
import time
import random
import hashlib
import requests
import paho.mqtt.client as mqtt
import ssl
from urllib.parse import urlparse
from datetime import datetime
import re
import pyfiglet
from termcolor import colored
import os
import sys
import subprocess

requirements = [
    "requests",
    "paho-mqtt",
    "pyfiglet",
    "termcolor"
]

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def banner():
    ascii_banner = pyfiglet.figlet_format("   NHAY POLL", font="slant")
    print(colored(ascii_banner, 'cyan', attrs=['bold']))
    print("=" * 60)
    print(colored("       Tool Spam Nhây Treo Messenger By Cte Vcl 🧸", 'white', attrs=['bold']))
    print("=" * 60)

def generate_offline_threading_id() -> str:
    ret = int(time.time() * 1000)
    value = random.randint(0, 4294967295)
    binary_str = format(value, "022b")[-22:]
    msgs = bin(ret)[2:] + binary_str
    return str(int(msgs, 2))

class Counter:
    def __init__(self, initial_value=0):
        self.value = initial_value
        
    def increment(self):
        self.value += 1
        return self.value
        
    @property
    def counter(self):
        return self.value

def parse_cookie_string(cookie_string):
    cookie_dict = {}
    cookies = cookie_string.split(";")
    for cookie in cookies:
        if "=" in cookie:
            key, value = cookie.strip().split("=", 1)
            cookie_dict[key] = value
    return cookie_dict

# ========== Lớp minhloi ==========

class minhloi:
    def __init__(self, cookie, mqtt_broker="broker.hivemq.com", mqtt_port=1883):
        self.cookie = cookie
        self.user_id = self.id_user()
        self.fb_dtsg = None
        self.jazoest = None
        self.rev = None
        self.init_params()

    def id_user(self):
        try:
            match = re.search(r"c_user=(\d+)", self.cookie)
            if not match:
                raise Exception("Cookie không hợp lệ")
            return match.group(1)
        except Exception as e:
            raise Exception(f"Lỗi khi lấy user_id: {str(e)}")

    def init_params(self):
        headers = {
            'Cookie': self.cookie,
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1'
        }
        urls = [
            'https://www.facebook.com',
            'https://mbasic.facebook.com',
            'https://m.facebook.com'
        ]

        for url in urls:
            try:
                response = requests.get(url, headers=headers, timeout=10)

                if response.status_code != 200:
                    continue

                fb_dtsg_patterns = [
                    r'"token":"(.*?)"',
                    r'name="fb_dtsg" value="(.*?)"',
                    r'"fb_dtsg":"(.*?)"',
                    r'fb_dtsg=([^&"]+)'
                ]
                jazoest_pattern = r'name="jazoest" value="(\d+)"'
                rev_pattern = r'"__rev":"(\d+)"'

                fb_dtsg = None
                for pattern in fb_dtsg_patterns:
                    match = re.search(pattern, response.text)
                    if match:
                        fb_dtsg = match.group(1)
                        break

                jazoest_match = re.search(jazoest_pattern, response.text)
                rev_match = re.search(rev_pattern, response.text)

                if fb_dtsg:
                    self.fb_dtsg = fb_dtsg
                    self.jazoest = jazoest_match.group(1) if jazoest_match else "22036"
                    self.rev = rev_match.group(1) if rev_match else "1015919737"
                    return

            except Exception as e:
                time.sleep(2)

        raise Exception("Không thể lấy được fb_dtsg từ bất kỳ URL nào")

# ========== Lớp fbTools ==========

class fbTools:
    def __init__(self, dataFB, threadID="0"):
        self.threadID = threadID
        self.dataGet = None
        self.dataFB = dataFB
        self.ProcessingTime = None
        self.last_seq_id = None
    
    def getAllThreadList(self):
        randomNumber = str(int(format(int(time.time() * 1000), "b") + ("0000000000000000000000" + format(int(random.random() * 4294967295), "b"))[-22:], 2))
        
        def formAll(dataFB, FBApiReqFriendlyName=None, docID=None, requireGraphql=None):
            global _req_counter
            if '_req_counter' not in globals():
                _req_counter = Counter(0)
            
            __reg = _req_counter.increment()
            dataForm = {}
            
            def str_base(number, base):
                if number < 0:
                    return "-" + str_base(-number, base)
                (d, m) = divmod(number, base)
                if d > 0:
                    return str_base(d, base) + str(m)
                return str(m)
            
            if requireGraphql is None:
                dataForm["fb_dtsg"] = dataFB["fb_dtsg"]
                dataForm["jazoest"] = dataFB["jazoest"]
                dataForm["__a"] = 1
                dataForm["__user"] = str(dataFB["FacebookID"])
                dataForm["__req"] = str_base(__reg, 36) 
                dataForm["__rev"] = dataFB["clientRevision"]
                dataForm["av"] = dataFB["FacebookID"]
                dataForm["fb_api_caller_class"] = "RelayModern"
                dataForm["fb_api_req_friendly_name"] = FBApiReqFriendlyName
                dataForm["server_timestamps"] = "true"
                dataForm["doc_id"] = str(docID)
            else:
                dataForm["fb_dtsg"] = dataFB["fb_dtsg"]
                dataForm["jazoest"] = dataFB["jazoest"]
                dataForm["__a"] = 1
                dataForm["__user"] = str(dataFB["FacebookID"])
                dataForm["__req"] = str_base(__reg, 36) 
                dataForm["__rev"] = dataFB["clientRevision"]
                dataForm["av"] = dataFB["FacebookID"]

            return dataForm
        
        dataForm = formAll(self.dataFB, requireGraphql=0)

        dataForm["queries"] = json.dumps({
            "o0": {
                "doc_id": "3336396659757871",
                "query_params": {
                    "limit": 20,
                    "before": None,
                    "tags": ["INBOX"],
                    "includeDeliveryReceipts": False,
                    "includeSeqID": True,
                }
            }
        })
        
        def mainRequests(url, data, cookies):
            return {
                "url": url,
                "data": data,
                "headers": {
                    "authority": "www.facebook.com",
                    "accept": "*/*",
                    "accept-language": "en-US,en;q=0.9,vi;q=0.8",
                    "content-type": "application/x-www-form-urlencoded",
                    "origin": "https://www.facebook.com",
                    "referer": "https://www.facebook.com/",
                    "sec-ch-ua": "\"Not?A_Brand\";v=\"8\", \"Chromium\";v=\"108\"",
                    "sec-ch-ua-mobile": "?0",
                    "sec-ch-ua-platform": "\"Windows\"",
                    "sec-fetch-dest": "empty",
                    "sec-fetch-mode": "cors",
                    "sec-fetch-site": "same-origin",
                    "user-agent": "Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36",
                    "x-fb-friendly-name": "FriendingCometFriendRequestsRootQueryRelayPreloader",
                    "x-fb-lsd": "YCb7tYCGWDI6JLU5Aexa1-"
                },
                "cookies": parse_cookie_string(cookies),
                "verify": True
            }
        
        sendRequests = requests.post(**mainRequests("https://www.facebook.com/api/graphqlbatch/", dataForm, self.dataFB["cookieFacebook"]))
        response_text = sendRequests.text
        self.ProcessingTime = sendRequests.elapsed.total_seconds()
        
        if response_text.startswith("for(;;);"):
            response_text = response_text[9:]
        
        if not response_text.strip():
            print("Error: Empty response from Facebook API")
            return False
            
        try:
            response_parts = response_text.split("\n")
            first_part = response_parts[0]
            
            if first_part.strip():
                response_data = json.loads(first_part)
                self.dataGet = first_part
                
                if "o0" in response_data and "data" in response_data["o0"] and "viewer" in response_data["o0"]["data"] and "message_threads" in response_data["o0"]["data"]["viewer"]:
                    self.last_seq_id = response_data["o0"]["data"]["viewer"]["message_threads"]["sync_sequence_id"]
                    return True
                else:
                    print("Error: Expected fields not found in response")
                    return False
            else:
                print("Error: Empty first part of response")
                return False
                
        except json.JSONDecodeError as e:
            print(f"JSON Decode Error: {e}")
            return False
        except KeyError as e:
            print(f"Key Error: {e}")
            return False

# ========== Lớp MessageSender ==========

class MessageSender:
    def __init__(self, fbt, dataFB, fb_instance):
        self.fbt = fbt
        self.dataFB = dataFB
        self.fb_instance = fb_instance
        self.mqtt = None
        self.ws_req_number = 0
        self.ws_task_number = 0
        self.syncToken = None
        self.lastSeqID = None
        self.req_callbacks = {}
        self.cookie_hash = hashlib.md5(dataFB['cookieFacebook'].encode()).hexdigest()
        self.connect_attempts = 0
        self.last_cleanup = time.time()

    def json_minimal(self, data):
        return json.dumps(data, separators=(",", ":"))

    def generate_client_id(self):
        import string
        def gen(length):
            return "".join(random.choices(string.ascii_lowercase + string.digits, k=length))
        return gen(8) + '-' + gen(4) + '-' + gen(4) + '-' + gen(4) + '-' + gen(12)

    def generate_session_id(self):
        return random.randint(1, 2 ** 53)

    def cleanup_memory(self):
        import gc
        current_time = time.time()
        if current_time - self.last_cleanup > 3600:
            self.req_callbacks.clear()
            gc.collect()
            self.last_cleanup = current_time

    def get_last_seq_id(self):
        success = self.fbt.getAllThreadList()
        if success:
            self.lastSeqID = self.fbt.last_seq_id
            return True
        else:
            print("Failed To Get Last Sequence ID. Check Facebook Authentication.")
            return False

    def on_disconnect(self, client, userdata, rc):
        if rc != 0:
            try:
                time.sleep(2)
                client.reconnect()
            except:
                pass

    def _messenger_queue_publish(self, client, userdata, flags, rc):
        if rc != 0:
            return

        topics = [("/t_ms", 0)]
        client.subscribe(topics)

        queue = {
            "sync_api_version": 10,
            "max_deltas_able_to_process": 1000,
            "delta_batch_size": 500,
            "encoding": "JSON",
            "entity_fbid": self.dataFB['FacebookID']
        }

        if self.syncToken is None:
            topic = "/messenger_sync_create_queue"
            queue["initial_titan_sequence_id"] = self.lastSeqID
            queue["device_params"] = None
        else:
            topic = "/messenger_sync_get_diffs"
            queue["last_seq_id"] = self.lastSeqID
            queue["sync_token"] = self.syncToken

        client.publish(
            topic,
            self.json_minimal(queue),
            qos=1,
            retain=False,
        )

    def connect_mqtt(self):
        if not self.lastSeqID:
            return False

        chat_on = self.json_minimal(True)
        session_id = self.generate_session_id()
        user = {
            "u": self.dataFB["FacebookID"],
            "s": session_id,
            "chat_on": chat_on,
            "fg": False,
            "d": self.generate_client_id(),
            "ct": "websocket",
            "aid": 219994525426954,
            "mqtt_sid": "",
            "cp": 3,
            "ecp": 10,
            "st": ["/t_ms", "/messenger_sync_get_diffs", "/messenger_sync_create_queue"],
            "pm": [],
            "dc": "",
            "no_auto_fg": True,
            "gas": None,
            "pack": [],
        }

        host = f"wss://edge-chat.messenger.com/chat?region=eag&sid={session_id}"
        options = {
            "client_id": "mqttwsclient",
            "username": self.json_minimal(user),
            "clean": True,
            "ws_options": {
                "headers": {
                    "Cookie": self.dataFB['cookieFacebook'],
                    "Origin": "https://www.messenger.com",
                    "User-Agent": "Mozilla/5.0 (Linux; Android 9; SM-G973U Build/PPR1.180610.011) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36",
                    "Referer": "https://www.messenger.com/",
                    "Host": "edge-chat.messenger.com",
                },
            },
            "keepalive": 10,
        }

        self.mqtt = mqtt.Client(
            client_id="mqttwsclient",
            clean_session=True,
            protocol=mqtt.MQTTv31,
            transport="websockets",
        )

        self.mqtt.tls_set(certfile=None, keyfile=None, cert_reqs=ssl.CERT_NONE, tls_version=ssl.PROTOCOL_TLSv1_2)
        self.mqtt.on_connect = self._messenger_queue_publish
        self.mqtt.on_disconnect = self.on_disconnect
        self.mqtt.username_pw_set(username=options["username"])

        parsed_host = urlparse(host)
        self.mqtt.ws_set_options(
            path=f"{parsed_host.path}?{parsed_host.query}",
            headers=options["ws_options"]["headers"],
        )

        try:
            self.mqtt.connect(
                host=options["ws_options"]["headers"]["Host"],
                port=443,
                keepalive=options["keepalive"],
            )

            self.mqtt.loop_start()
            time.sleep(2)  # Chờ kết nối ổn định
            return True
        except Exception as e:
            return False

    def stop(self):
        if self.mqtt:
            try:
                self.mqtt.disconnect()
                self.mqtt.loop_stop()
            except:
                pass
        self.cleanup_memory()

    def createPollMqtt(self, title, options, thread_id):
        if self.mqtt is None:
            return False

        self.cleanup_memory()

        self.ws_req_number += 1
        self.ws_task_number += 1

        task_payload = {
            "question_text": title,
            "thread_key": thread_id,
            "options": options,
            "sync_group": 1,
        }

        task = {
            "failure_count": None,
            "label": "163",
            "payload": json.dumps(task_payload, separators=(",", ":")),
            "queue_name": "poll_creation",
            "task_id": self.ws_task_number,
        }

        content = {
            "app_id": "2220391788200892",
            "payload": json.dumps({
                "data_trace_id": None,
                "epoch_id": int(generate_offline_threading_id()),
                "tasks": [task],
                "version_id": "7158486590867448",
            }, separators=(",", ":")),
            "request_id": self.ws_req_number,
            "type": 3,
        }

        try:
            self.mqtt.publish(
                topic="/ls_req",
                payload=json.dumps(content, separators=(",", ":")),
                qos=1,
                retain=False,
            )
            time.sleep(0.5)  # Chờ gửi thành công
            return True
        except Exception as e:
            return False

# ========== Hàm gửi poll đa cookie và đa box ==========

def treo_poll():
    clear()
    banner()
    # Nhập id box
    id_list = []
    stt = 1
    while True:
        idbox = input(colored("Nhập ID Box (Ấn 'enter' để dừng nhập): ", 'yellow', attrs=['bold'])).strip()
        if idbox.lower() in ['', 'enter']:
            print('Đã lưu ID Box')
            for id_ in id_list:
                print(f'  {id_}')
            break
        if idbox.isdigit():
            id_list.append(idbox)
            stt += 1

    # Nhập danh sách cookie
    cookie_list = []
    stt = 1
    while True:
        ck = input(colored("Nhập cookie (Ấn 'enter' để dừng nhập): ", 'yellow', attrs=['bold'])).strip()
        if ck.lower() in ['', 'enter']:
            print('Đã lưu cookie')
            if not cookie_list:
                print('Không có cookie nào được lưu')
            else:
                for i, c in enumerate(cookie_list, 1):
                    print(f'  Cookie {i}: {c[:25]}...')
            break
        if 'c_user=' in ck and 'xs=' in ck:
            cookie_list.append(ck)
            stt += 1

    # Nhập file tiêu đề poll
    poll_file = input(colored("Nhập file.txt chứa tiêu đề poll: ", 'yellow', attrs=['bold'])).strip()
    if not poll_file.endswith('.txt'):
        poll_file += '.txt'
    
    if not os.path.exists(poll_file):
        print(colored(f'File {poll_file} không tồn tại!', 'red'))
        return

    # Đọc nội dung file poll
    try:
        with open(poll_file, 'r', encoding='utf-8') as f:
            poll_titles = [line.strip() for line in f if line.strip()]
        
        if not poll_titles:
            print(colored('File poll trống!', 'red'))
            return
        
        print(colored(f'Đã đọc {len(poll_titles)} tiêu đề poll', 'green'))
    except Exception as e:
        print(colored(f'Lỗi đọc file poll: {e}', 'red'))
        return

    # Nhập delay
    try:
        delay = int(input(colored('Nhập delay (giây): ', 'yellow', attrs=['bold'])).strip())
    except:
        delay = 5
        print(colored(f'Đã đặt delay mặc định: {delay} giây', 'yellow'))

    # Options mặc định cho poll
    default_options = ["Bá war", "Bá sàn", "Hot boiz sàn treo"]

    print(colored('Đã bắt đầu gửi poll...', 'green', attrs=['bold']))
    
    # Lặp vô hạn giống natra.py
    while True:
        for i, ck in enumerate(cookie_list):
            try:
                print(colored(f'\n[{datetime.now().strftime("%H:%M:%S")}] Xử lý cookie {i+1}/{len(cookie_list)}', 'cyan'))
                
                # Khởi tạo Facebook instance
                fb = minhloi(ck)
                dataFB = {
                    "FacebookID": fb.user_id,
                    "fb_dtsg": fb.fb_dtsg,
                    "clientRevision": fb.rev,
                    "jazoest": fb.jazoest,
                    "cookieFacebook": ck
                }
                
                # Khởi tạo tools
                fbt = fbTools(dataFB)
                sender = MessageSender(fbt, dataFB, fb)
                
                # Lấy last_seq_id và kết nối MQTT
                if not sender.get_last_seq_id():
                    print(colored('Không thể lấy last_seq_id', 'red'))
                    continue
                
                if not sender.connect_mqtt():
                    print(colored('Không thể kết nối MQTT', 'red'))
                    continue
                
                print(colored('Đã kết nối MQTT thành công', 'green'))
                
                # Gửi poll cho từng ID box
                for idbox in id_list:
                    print(colored(f'\nGửi poll tới box: {idbox}', 'yellow'))
                    
                    # Gửi từng tiêu đề poll
                    for title in poll_titles:
                        titles = title.split(',') if ',' in title else [title]
                        
                        for single_title in titles:
                            single_title = single_title.strip()
                            if not single_title:
                                continue
                            
                            print(colored(f'  Tạo poll: "{single_title}"', 'white'))
                            
                            success = sender.createPollMqtt(single_title, default_options, idbox)
                            
                            if success:
                                print(colored(f'    ✓ Đã tạo poll thành công', 'green'))
                            else:
                                print(colored(f'    ✗ Tạo poll thất bại', 'red'))
                            
                            # Delay giữa các poll
                            time.sleep(delay)
                    
                    # Delay giữa các box
                    time.sleep(1)
                
                # Dừng sender
                sender.stop()
                print(colored(f'Hoàn thành cookie {i+1}', 'green'))
                
            except Exception as e:
                print(colored(f'Lỗi với cookie {i+1}: {e}', 'red'))
                continue
            
            # Delay giữa các cookie
            time.sleep(2)
        
        print(colored(f'\n[{datetime.now().strftime("%H:%M:%S")}] Đã hoàn thành một chu kỳ, bắt đầu chu kỳ mới...\n', 'cyan', attrs=['bold']))

if __name__ == '__main__':
    treo_poll()