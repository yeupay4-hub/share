# nhaydis_standalone.py
import discord
import asyncio
import random
import time

class NhayDisBot:
    def __init__(self):
        self.token = None
        self.channel_ids = []
        self.user_id_to_tag = None
        self.user_name_to_tag = None
        self.delay = None
        self.running = False
        self.client = discord.Client(intents=discord.Intents.default())
        self.setup_events()
        
    def setup_events(self):
        @self.client.event
        async def on_ready():
            print(f'✅ Đã đăng nhập với tên: {self.client.user}')
            print(f'🔧 Bot ID: {self.client.user.id}')
            print(f'📊 Số kênh sẽ spam: {len(self.channel_ids)}')
            print(f'🏷️ Tag user: {self.user_name_to_tag} (ID: {self.user_id_to_tag})')
            print(f'⏱️ Delay: {self.delay} giây')
            print('🚀 Bắt đầu nhây Discord...')
            asyncio.create_task(self.nhay_loop())
            
    async def nhay_loop(self):
        self.running = True
        
        # Đọc file nhay.txt
        try:
            with open("nhay.txt", "r", encoding="utf-8") as f:
                messages = [line.strip() for line in f if line.strip()]
        except FileNotFoundError:
            print("❌ Không tìm thấy file nhay.txt")
            messages = ["Nhây Discord bot đang chạy!"]
            
        if not messages:
            messages = ["Nhây Discord bot đang chạy!"]
            
        index = 0
        
        while self.running:
            for channel_id in self.channel_ids:
                if not self.running:
                    break
                    
                try:
                    channel = self.client.get_channel(channel_id)
                    if channel is None:
                        print(f"⚠️ Không tìm thấy kênh ID: {channel_id}")
                        continue
                        
                    # Lấy tin nhắn
                    message = messages[index % len(messages)]
                    index += 1
                    
                    # Tạo tin nhắn với tag fake soạn
                    # Fake typing (bắt đầu soạn)
                    await channel.trigger_typing()
                    await asyncio.sleep(random.uniform(1, 3))
                    
                    # Gửi tin nhắn với tag
                    if self.user_id_to_tag:
                        content = f"{message} <@{self.user_id_to_tag}>"
                    else:
                        content = message
                        
                    await channel.send(content)
                    
                    print(f"✅ Đã gửi đến #{channel.name}: {message[:50]}...")
                    
                    # Delay
                    await asyncio.sleep(self.delay)
                    
                except discord.Forbidden:
                    print(f"⛔ Không có quyền gửi tin trong kênh {channel_id}")
                except discord.HTTPException as e:
                    print(f"❌ Lỗi HTTP: {e}")
                except Exception as e:
                    print(f"❌ Lỗi: {e}")
                    
    def get_input(self):
        """Lấy thông tin đầu vào từ người dùng"""
        print("=" * 50)
        print("🤖 NHÂY DISCORD - TAG FAKE SOẠN")
        print("=" * 50)
        
        # Nhập token bot
        self.token = input("=> Token bot Discord: ").strip()
        if not self.token:
            print("❌ Token không được để trống!")
            return False
            
        # Nhập danh sách kênh
        channels_input = input("=> ID kênh Discord (cách nhau bằng dấu phẩy): ").strip()
        if not channels_input:
            print("❌ Cần ít nhất một kênh!")
            return False
            
        try:
            self.channel_ids = [int(cid.strip()) for cid in channels_input.split(",")]
        except ValueError:
            print("❌ ID kênh phải là số!")
            return False
            
        # Nhập user cần tag
        user_input = input("=> ID người cần tag (để trống nếu không tag): ").strip()
        if user_input:
            try:
                self.user_id_to_tag = int(user_input)
                self.user_name_to_tag = user_input
            except ValueError:
                print("⚠️ ID không hợp lệ, sẽ không tag ai")
                self.user_id_to_tag = None
        else:
            self.user_id_to_tag = None
            
        # Nhập delay
        delay_input = input("=> Delay giữa các tin (giây, mặc định: 5): ").strip()
        if delay_input:
            try:
                self.delay = float(delay_input)
                if self.delay < 1:
                    print("⚠️ Delay quá thấp, đặt thành 1 giây")
                    self.delay = 1
            except ValueError:
                print("⚠️ Delay không hợp lệ, sử dụng mặc định 5 giây")
                self.delay = 5
        else:
            self.delay = 5
            
        # Xác nhận
        print("\n" + "=" * 50)
        print("📋 THÔNG TIN CẤU HÌNH:")
        print(f"• Số kênh: {len(self.channel_ids)}")
        print(f"• Tag user: {'Có' if self.user_id_to_tag else 'Không'}")
        if self.user_id_to_tag:
            print(f"• User ID: {self.user_id_to_tag}")
        print(f"• Delay: {self.delay} giây")
        print("=" * 50)
        
        confirm = input("\n✅ Bắt đầu chạy? (y/n): ").strip().lower()
        return confirm == 'y'
        
    def stop(self):
        """Dừng bot"""
        self.running = False
        print("\n🛑 Đang dừng bot...")
        
    def run(self):
        """Chạy bot"""
        if not self.get_input():
            print("❌ Khởi động thất bại!")
            return
            
        try:
            print("\n⏳ Đang kết nối Discord...")
            self.client.run(self.token)
        except discord.LoginFailure:
            print("❌ Token không hợp lệ!")
        except KeyboardInterrupt:
            print("\n\n👋 Đã dừng bởi người dùng")
        except Exception as e:
            print(f"❌ Lỗi không xác định: {e}")

def main():
    """Hàm chính"""
    bot = NhayDisBot()
    
    # Chạy bot
    bot.run()
    
    # Nếu bot đã dừng
    input("\nNhấn Enter để thoát...")

if __name__ == "__main__":
    main()