import os
import re
import json
import time
import requests
import pyfiglet
import asyncio
import aiohttp
from bs4 import BeautifulSoup
from termcolor import colored

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def banner():
    ascii_banner = pyfiglet.figlet_format("   NATRA", font="slant")
    print(colored(ascii_banner, 'cyan', attrs=['bold']))
    print("=" * 60)
    print(colored("       Tool Treo Mess & Dis By Natra Socola", 'white', attrs=['bold']))
    print("=" * 60)

def get_uid(cookie):
    try:
        return re.search(r'c_user=(\d+)', cookie).group(1)
    except:
        return '0'

def get_fb_dtsg_jazoest(cookie, target_id):
    try:
        response = requests.get(
            f'https://mbasic.facebook.com/privacy/touch/block/confirm/?bid={target_id}',
            headers={ 'cookie': cookie, 'user-agent': 'Mozilla/5.0' }
        ).text
        fb_dtsg = re.search('name="fb_dtsg" value="([^"]+)"', response).group(1)
        jazoest = re.search('name="jazoest" value="([^"]+)"', response).group(1)
        return fb_dtsg, jazoest
    except:
        return None, None

def get_eaag_token(cookie):
    try:
        res = requests.get(
            'https://business.facebook.com/business_locations',
            headers={ 'cookie': cookie, 'user-agent': 'Mozilla/5.0' }
        )
        return re.search(r'EAAG\w+', res.text).group()
    except:
        return None

def send_message(idbox, fb_dtsg, jazoest, cookie, file_path):
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            message_body = file.read().strip()
        uid = get_uid(cookie)
        timestamp = int(time.time() * 1000)
        data = {
            'thread_fbid': idbox,
            'action_type': 'ma-type:user-generated-message',
            'body': message_body,
            'client': 'mercury',
            'author': f'fbid:{uid}',
            'timestamp': timestamp,
            'offline_threading_id': str(timestamp),
            'message_id': str(timestamp),
            'source': 'source:chat:web',
            '__user': uid,
            '__a': '1',
            '__req': '1b',
            '__rev': '1015919737',
            'fb_dtsg': fb_dtsg,
            'jazoest': jazoest
        }
        headers = {
            'Cookie': cookie,
            'User-Agent': 'Mozilla/5.0',
            'Content-Type': 'application/x-www-form-urlencoded'
        }
        response = requests.post('https://www.facebook.com/messaging/send/', data=data, headers=headers)
        return response.status_code == 200
    except Exception as e:
        print(f'Lỗi gửi tới ID {idbox}: {e}')
        return False

def treo_mess():
    clear()
    banner()
    id_list = []
    stt = 1
    while True:
        idbox = input(colored("Nhập ID Box (Ấn 'enter' để dừng nhập): ", 'yellow', attrs=['bold'])).strip()
        if idbox.lower() in ['', 'enter']:
            print('Đã lưu ID Box')
            for id_ in id_list:
                print(f'  {id_}')
            break
        if idbox.isdigit():
            id_list.append(idbox)
            stt += 1

    cookie_list = []
    stt = 1
    while True:
        ck = input(colored("Nhập cookie (Ấn 'enter' để dừng nhập): ", 'yellow', attrs=['bold'])).strip()
        if ck.lower() in ['', 'enter']:
            print('Đã lưu cookie')
            if not cookie_list:
                print('Không có cookie nào được lưu')
            else:
                for i, c in enumerate(cookie_list, 1):
                    print(f'  {c[:25]}...')
            break
        if 'c_user=' in ck and 'xs=' in ck:
            cookie_list.append(ck)
            stt += 1

    file_list = []
    stt = 1
    while True:
        name_file = input(colored("Nhập file.txt (Ấn 'enter' để dừng nhập): ", 'yellow', attrs=['bold'])).strip()
        if name_file.lower() in ['', 'enter']:
            print('Đã lưu file.txt')
            if not file_list:
                print('Không có file.txt nào được lưu')
            else:
                for i, f in enumerate(file_list, 1):
                    print(f'  {f[:25]}')
            break
        if name_file.endswith('.txt'):
            file_list.append(name_file)
            stt += 1

    id_user_list = []
    name_user_list = []
    for index, ck in enumerate(cookie_list, 1):
        try:
            uid = get_uid(ck)
            id_user_list.append(uid)
            token = get_eaag_token(ck)
            if token:
                res = requests.get(
                    f'https://graph.facebook.com/{uid}?fields=name&access_token={token}',
                    headers={'cookie': ck, 'user-agent': 'Mozilla/5.0'}
                ).json()
                name = res.get('name', f'User_{index}')
                name_user_list.append({'name': name, 'id': uid, 'cookie': ck, 'token': token})
            else:
                name_user_list.append({'name': f'User_{index}', 'id': uid, 'cookie': ck, 'token': None})
                print(f'Không lấy được fb_dtsg từ cookie [{ck[:30]}...]')
        except Exception as e:
            print(f'[{index}] Lỗi xử lý: {e}')

    delay = int(input(colored('Nhập delay: ', 'yellow', attrs=['bold'])))

    print('Đã bắt đầu gửi tin nhắn')
    while True:
        for i, ck in enumerate(cookie_list):
            fb_dtsg, jazoest = get_fb_dtsg_jazoest(ck, id_list[0])
            if fb_dtsg and jazoest:
                for idbox in id_list:
                    for file_path in file_list:
                        success = send_message(idbox, fb_dtsg, jazoest, ck, file_path)
                        user_name = name_user_list[i]['name']
                        if success:
                            print(f'Tin nhắn được gửi thành công tới: {idbox}')
                        else:
                            print(f'Gửi tin nhắn thất bại tới: {idbox}')
                        time.sleep(delay)
            else:
                print(f'Không thể lấy fb_dtsg/jazoest từ cookie: {ck[:20]}...')

if __name__ == '__main__':
    treo_mess()
