import multiprocessing
import requests
import os
import re
import json
import time
import random
import pyfiglet

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def check_live(cookie):
    try:
        if 'c_user=' not in cookie:
            return {"status": "failed", "msg": "Cookie không chứa user_id"}
        
        user_id = cookie.split('c_user=')[1].split(';')[0]
        headers = {
            'authority': 'm.facebook.com',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'accept-language': 'vi-VN,vi;q=0.9',
            'cache-control': 'max-age=0',
            'cookie': cookie,
            'sec-ch-ua': '"Not_A Brand";v="99", "Google Chrome";v="109", "Chromium";v="109"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-ch-ua-platform-version': '"0.1.0"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36'
        }
        profile_response = requests.get(f'https://m.facebook.com/profile.php?id={user_id}', headers=headers, timeout=30)
        name = profile_response.text.split('<title>')[1].split('<')[0].strip()
        return {
            "status": "success",
            "name": name,
            "user_id": user_id,
            "msg": "successful"
        }
    except Exception as e:
        return {"status": "failed", "msg": f"Lỗi xảy ra: {str(e)}"}

def load_file(file_path):
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            lines = [line.strip() for line in f.readlines() if line.strip()]
        if not lines:
            raise Exception(f"File {file_path} trống!")
        return lines
    except Exception as e:
        raise Exception(f"Lỗi đọc file {file_path}: {str(e)}")

def parse_selection(input_str, max_index):
    try:
        numbers = [int(i.strip()) for i in input_str.split(',')]
        return [n for n in numbers if 1 <= n <= max_index]
    except:
        print("Định dạng không hợp lệ!")
        return []

class Messenger:
    def __init__(self, cookie):
        self.cookie = cookie
        self.user_id = self.get_user_id()
        self.fb_dtsg = None
        self.jazoest = None
        self.init_params()
        self.user_agents = [
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36",
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36"
        ]

    def get_user_id(self):
        try:
            return re.search(r"c_user=(\d+)", self.cookie).group(1)
        except:
            raise Exception("Cookie không hợp lệ")

    def init_params(self):
        headers = {
            'Cookie': self.cookie,
            'User-Agent': 'Mozilla/5.0'
        }
        try:
            for url in ['https://www.facebook.com', 'https://mbasic.facebook.com', 'https://m.facebook.com']:
                response = requests.get(url, headers=headers, timeout=10)
                match_dtsg = re.search(r'name="fb_dtsg" value="(.*?)"', response.text)
                match_jazoest = re.search(r'name="jazoest" value="(.*?)"', response.text)
                if match_dtsg:
                    self.fb_dtsg = match_dtsg.group(1)
                if match_jazoest:
                    self.jazoest = match_jazoest.group(1)
                if match_dtsg and match_jazoest:
                    return
            raise Exception("Không tìm thấy fb_dtsg hoặc jazoest")
        except Exception as e:
            raise Exception(f"Lỗi khởi tạo: {str(e)}")

    def get_private_thread_list(self, limit=100):
        """
        Lấy danh sách cuộc trò chuyện riêng tư (private chats)
        """
        headers = {
            'Cookie': self.cookie,
            'User-Agent': random.choice(self.user_agents),
            'Content-Type': 'application/x-www-form-urlencoded',
            'Accept': '*/*',
            'Accept-Language': 'en-US,en;q=0.9,vi;q=0.8',
            'Origin': 'https://www.facebook.com',
            'Referer': 'https://www.facebook.com/',
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'same-origin',
            'X-FB-Friendly-Name': 'MessengerThreadListQuery',
            'X-FB-LSD': 'null'
        }
        
        form_data = {
            "av": self.user_id,
            "__user": self.user_id,
            "__a": "1",
            "__req": "1b",
            "__hs": "19234.HYP:comet_pkg.2.1..2.1",
            "dpr": "1",
            "__ccg": "EXCELLENT",
            "__rev": "1015919737",
            "__comet_req": "15",
            "fb_dtsg": self.fb_dtsg,
            "jazoest": self.jazoest,
            "lsd": "null",
            "__spin_r": "",
            "__spin_b": "trunk",
            "__spin_t": str(int(time.time())),
            "queries": json.dumps({
                "o0": {
                    "doc_id": "3336396659757871",
                    "query_params": {
                        "limit": limit,
                        "before": None,
                        "tags": ["INBOX"],
                        "includeDeliveryReceipts": False,
                        "includeSeqID": True,
                    }
                }
            })
        }
        
        try:
            response = requests.post(
                'https://www.facebook.com/api/graphqlbatch/',
                data=form_data,
                headers=headers,
                timeout=15
            )
            
            if response.status_code != 200:
                return {"error": f"HTTP Error: {response.status_code}"}
            
            # Xử lý response đặc biệt của Facebook
            if response.text.startswith('for (;;);'):
                response_text = response.text[9:]
            else:
                response_text = response.text
            
            try:
                data = json.loads(response_text)
            except:
                # Thử tìm JSON trong response
                json_match = re.search(r'\{.*\}', response_text)
                if json_match:
                    data = json.loads(json_match.group())
                else:
                    return {"error": "Không thể parse JSON response"}
            
            if "o0" not in data:
                return {"error": "Không tìm thấy dữ liệu thread list"}
            
            if "errors" in data["o0"]:
                return {"error": f"Facebook API Error: {data['o0']['errors'][0]['summary']}"}
            
            threads = data["o0"]["data"]["viewer"]["message_threads"]["nodes"]
            private_chats = []
            
            for thread in threads:
                # Chỉ lấy các cuộc trò chuyện riêng (1-1)
                if thread.get("is_group_thread") or thread.get("thread_type") != "ONE_TO_ONE":
                    continue
                
                thread_key = thread.get("thread_key")
                if not thread_key:
                    continue
                
                # Lấy ID thread (có thể là other_user_id hoặc thread_fbid)
                thread_id = None
                if thread_key.get("other_user_id"):
                    thread_id = thread_key["other_user_id"]
                elif thread_key.get("thread_fbid"):
                    thread_id = thread_key["thread_fbid"]
                else:
                    continue
                
                # Lấy tên người dùng
                thread_name = thread.get("name", "Người dùng Facebook")
                if not thread_name or thread_name == "Không có tên":
                    participants = thread.get("all_participants", {}).get("edges", [])
                    for participant in participants:
                        node = participant.get("node", {})
                        if node.get("id") != self.user_id:
                            thread_name = node.get("messaging_actor", {}).get("name", "Người dùng Facebook")
                            break
                
                private_chats.append({
                    "thread_id": thread_id,
                    "thread_name": thread_name,
                })
            
            return {
                "success": True,
                "thread_count": len(private_chats),
                "threads": private_chats
            }
            
        except json.JSONDecodeError as e:
            return {"error": f"Lỗi parse JSON: {str(e)}"}
        except Exception as e:
            return {"error": f"Lỗi không xác định: {str(e)}"}

    def send_message(self, recipient_id, content):
        """
        Gửi tin nhắn riêng (1-1)
        Sử dụng API mới của Facebook Messenger
        """
        headers = {
            'User-Agent': random.choice(self.user_agents),
            'Cookie': self.cookie,
            'Content-Type': 'application/x-www-form-urlencoded',
            'Origin': 'https://www.facebook.com',
            'Referer': f'https://www.facebook.com/messages/t/{recipient_id}',
            'Accept': '*/*',
            'Accept-Language': 'en-US,en;q=0.9',
            'X-Requested-With': 'XMLHttpRequest',
        }
        
        # Tạo payload cho API gửi tin nhắn
        ts = str(int(time.time() * 1000))
        
        payload = {
            "action_type": "ma-type:user-generated-message",
            "body": content,
            "ephemeral_ttl_mode": "0",
            "has_attachment": "false",
            "message_id": ts,
            "offline_threading_id": ts,
            "source": "source:chat:web",
            "specific_to_list[0]": f"fbid:{recipient_id}",
            "specific_to_list[1]": f"fbid:{self.user_id}",
            "timestamp": ts,
            "ui_push_phase": "C3",
            "__user": self.user_id,
            "__a": "1",
            "__req": "1b",
            "__rev": "1015919737",
            "fb_dtsg": self.fb_dtsg,
            "jazoest": self.jazoest,
        }
        
        try:
            response = requests.post(
                "https://www.facebook.com/messaging/send/",
                headers=headers,
                data=payload,
                timeout=15
            )
            
            if response.status_code == 200:
                # Kiểm tra response có thành công không
                if "success" in response.text.lower() or "true" in response.text.lower():
                    return "success"
                else:
                    # Thử phương pháp backup
                    return self.send_message_backup(recipient_id, content)
            else:
                return "failed"
                
        except Exception as e:
            print(f"Lỗi gửi tin nhắn: {str(e)}")
            return "failed"
    
    def send_message_backup(self, recipient_id, content):
        """
        Phương pháp backup để gửi tin nhắn
        """
        headers = {
            'User-Agent': random.choice(self.user_agents),
            'Cookie': self.cookie,
            'Content-Type': 'application/x-www-form-urlencoded',
            'Origin': 'https://www.facebook.com',
            'Referer': f'https://www.facebook.com/messages/t/{recipient_id}',
        }
        
        ts = str(int(time.time() * 1000))
        
        payload = {
            "ids[0]": recipient_id,
            "body": content,
            "waterfall_source": "message",
            "client": "web_messenger",
            "action": "send",
            "ephemeral_ttl_mode": "0",
            "has_attachment": "false",
            "message_id": ts,
            "offline_threading_id": ts,
            "source": "source:chat:web",
            "timestamp": ts,
            "__user": self.user_id,
            "__a": "1",
            "__req": "1b",
            "fb_dtsg": self.fb_dtsg,
            "jazoest": self.jazoest,
        }
        
        try:
            response = requests.post(
                "https://www.facebook.com/ajax/mercury/send_messages.php",
                headers=headers,
                data=payload,
                timeout=15
            )
            return "success" if response.status_code == 200 else "failed"
        except:
            return "failed"

def start_spam(cookie, account_name, user_id, thread_ids, thread_names, delay, message_lines):
    """
    Hàm spam tin nhắn riêng
    """
    try:
        messenger = Messenger(cookie)
        message_index = 0
        
        print(f"\n🔔 Bắt đầu spam cho {account_name}...")
        print(f"📱 Số cuộc trò chuyện: {len(thread_ids)}")
        print(f"💬 Số tin nhắn: {len(message_lines)}")
        print(f"⏰ Delay: {delay} giây")
        print("-" * 50)
        
        while True:
            for thread_id, thread_name in zip(thread_ids, thread_names):
                # Lấy nội dung tin nhắn
                content = message_lines[message_index]
                
                # Gửi tin nhắn
                status = messenger.send_message(thread_id, content)
                status_text = "✅ Thành Công" if status == "success" else "❌ Thất Bại"
                
                # Hiển thị thông tin
                current_time = time.strftime("%H:%M:%S")
                print(f"[{current_time}] {account_name} → {thread_name[:20]}...: {status_text}")
                
                # Chuyển sang tin nhắn tiếp theo
                message_index = (message_index + 1) % len(message_lines)
                
                # Delay
                time.sleep(delay)
                
    except Exception as e:
        print(f"\n❌ Lỗi tài khoản {account_name}: {str(e)}")
        import traceback
        traceback.print_exc()

def start_multiple_accounts():
    clear()
    print(pyfiglet.figlet_format('Private Messenger', font="slant"))
    print("=" * 60)
    print("🚀 Tool spam tin nhắn riêng tư (1-1)")
    print("=" * 60)
    
    try:
        num_accounts = int(input("💠 Nhập số lượng acc muốn chạy: "))
        if num_accounts < 1:
            print("Số lượng tài khoản phải lớn hơn 0. Thoát chương trình.")
            return
    except ValueError:
        print("Số lượng tài khoản phải là số nguyên. Thoát chương trình.")
        return

    processes = []
    for i in range(num_accounts):
        print(f"\n" + "=" * 60)
        print(f"THÔNG TIN TÀI KHOẢN {i+1}/{num_accounts}")
        print("=" * 60)
        
        cookie = input("🍪 Nhập Cookie: ").strip()
        if not cookie:
            print("Cookie không được để trống. Bỏ qua tài khoản này.")
            continue
        
        # Kiểm tra cookie
        cl = check_live(cookie)
        if cl["status"] == "success":
            print(f"✅ Facebook: {cl['name']} (ID: {cl['user_id']}) - Cookie Sống!")
        else:
            print(f"❌ Lỗi: {cl['msg']}. Bỏ qua tài khoản này.")
            continue

        try:
            # Khởi tạo Messenger
            messenger = Messenger(cookie)
            
            # Lấy danh sách chat riêng
            print(f"\n⏳ Đang lấy danh sách chat riêng...")
            result = messenger.get_private_thread_list(limit=50)
            
            if "error" in result:
                print(f"❌ Lỗi: {result['error']}. Bỏ qua tài khoản này.")
                continue
            
            threads_list = result['threads']
            if not threads_list:
                print("❌ Không tìm thấy cuộc trò chuyện riêng nào.")
                print("💡 Mẹo: Hãy nhắn tin với một vài người trước khi chạy tool.")
                continue
            
            print(f"\n✅ Tìm thấy {len(threads_list)} cuộc trò chuyện:")
            print("=" * 60)
            for idx, thread in enumerate(threads_list, 1):
                name = thread['thread_name'][:40] + "..." if len(thread['thread_name']) > 40 else thread['thread_name']
                print(f"{idx:2d}. {name}")
            
            print("=" * 60)
            
            # Chọn cuộc trò chuyện
            raw = input("\n🔸 Nhập số thứ tự cuộc trò chuyện (VD: 1 hoặc 1,2,3): ")
            selected = parse_selection(raw, len(threads_list))
            
            if not selected:
                print("❌ Không chọn cuộc trò chuyện nào! Bỏ qua tài khoản này.")
                continue
            
            # Lấy thông tin đã chọn
            selected_ids = [threads_list[i - 1]['thread_id'] for i in selected]
            selected_names = [threads_list[i - 1]['thread_name'] for i in selected]
            
            # Nhập file tin nhắn
            file_txt = input("\n📂 Nhập tên file .txt chứa nội dung (m.txt): ").strip()
            if not file_txt:
                file_txt = "m.txt"
            
            try:
                message_lines = load_file(file_txt)
                print(f"✅ Đã tải {len(message_lines)} tin nhắn từ {file_txt}")
            except Exception as e:
                print(f"❌ Lỗi đọc file: {str(e)}")
                continue
            
            # Nhập delay
            try:
                delay_input = input("\n⏳ Nhập delay giữa các tin nhắn (mặc định 3): ").strip()
                delay = int(delay_input) if delay_input else 3
                if delay < 1:
                    print("⚠️ Delay quá ngắn, tự động đặt thành 3 giây")
                    delay = 3
            except ValueError:
                print("⚠️ Delay không hợp lệ, đặt mặc định 3 giây")
                delay = 3
            
            # Hiển thị thông tin
            print(f"\n" + "=" * 60)
            print(f"THÔNG TIN CHẠY BOT:")
            print(f"👤 Tài khoản: {cl['name']}")
            print(f"💬 Số chat: {len(selected_ids)}")
            print(f"📝 Số tin nhắn: {len(message_lines)}")
            print(f"⏰ Delay: {delay} giây")
            print("=" * 60)
            
            confirm = input("\n🔸 Bắt đầu chạy bot? (y/n): ").strip().lower()
            if confirm != 'y':
                print("❌ Đã hủy tài khoản này.")
                continue
            
            # Khởi động process
            print(f"\n🚀 Đang khởi động bot cho {cl['name']}...")
            p = multiprocessing.Process(
                target=start_spam,
                args=(cookie, cl['name'], cl['user_id'], selected_ids, selected_names, delay, message_lines)
            )
            processes.append(p)
            p.start()
            
            # Chờ một chút để tránh conflict
            time.sleep(2)
            
        except Exception as e:
            print(f"❌ Lỗi tài khoản: {str(e)}")
            import traceback
            traceback.print_exc()
            continue
    
    if not processes:
        print("\n❌ Không có tài khoản nào được khởi động.")
        return
    
    print("\n" + "=" * 60)
    print("✅ TẤT CẢ BOT ĐÃ KHỞI ĐỘNG THÀNH CÔNG")
    print("📌 Nhấn Ctrl+C để dừng.")
    print("=" * 60)
    
    try:
        # Hiển thị trạng thái
        while True:
            time.sleep(5)
            print(f"\n📊 Đang chạy {len(processes)} bot... [Ctrl+C để dừng]")
            
    except KeyboardInterrupt:
        print("\n\n🛑 Đang dừng tất cả bot...")
        for p in processes:
            p.terminate()
            p.join(timeout=2)
        
        print("👋 Đã dừng tất cả bot. Tạm biệt!")
        time.sleep(2)

if __name__ == "__main__":
    start_multiple_accounts()