import requests, re, json, time, random, os, sys
from colorama import Fore, Style, init
init(autoreset=True)

ngonnhay = [
"sao kia", "manh di ma", "kem ak", "sao kia", "son de", "run ak", "thg an hai","cay tao ak", "cay lam ak", "sao roi nhi", "bat luc ak", "lien tuc de", "tiep de m","nhay keo k e", "ga vay e", "hoc lom ak", "ko slow ma","speed de", "hai vai l","m dot ak", "thg oc cut", "chay de", "chat le dei", "co len", "mo coi ak", "cay ak", "ccho cayya ak", "oc cac ak", "chay ak em", "sua mau dei", "sua le dei", "tk dot", "tk oc dai", "sua le de", "manh kg", "manh ma e", "man ma em", "tk dot", "ui mo coi", "sua lej9 dei", "oc loz ak", "tk boai ngu", "son dc kg", "oc trau ak", "le ma em", "hot nhay ma", " tk oc dai", "sua manh kg", "m bi ngu ak", "sua mau kg", "oc trau ak", "speed em", "le nun ma", "tk dot cut", "bi ngu ak", "son de em", "ccho dien", "nhanh vl ma", "tay ma em", "slow ak", "oc boai ak", "tk dot", " bia ngu ak", "sua le nun", "phat bieu le", "tk dot nay", "mo coi me ak", "tk ngu", "sao da", "anh man mak", "cay akk", "sua mauu", "sloww akk", "le em", "nhanh em", "clmkks", "con cho dien", "sua em", "speed ma", "m slow ay", "m slow vl", "anh speed vkl", "le em", "clm ngu ak", "tk ga nay", "con loz", "sua le lun em", "clm dot ak", "keo man cai", "man off mxh de", "kg dam ak", "tk ngu ren", "cay r ak", "cay cmnr", "m cay ro", "nhanh ti", "le len e", "co de", "sap dc r", "co gang em", "bat luc r ak", "ui tk ga", "ga bat luc", "duoi r ak", "moi tay ak", "kakakak", "sua le nun", "chill ma", "bth ma em", "m bat on ak", "anh dg chill", "sua manh em", "kg dc treo nha", "tay vs bo de", "cn boai", "nao cho ak", "clm", "sua mau de", "ga ak m", "slow r ak m", "duoi r ak", "kh nghi ngoi", "lien tuc ma", "lien tuc nun", "chat lien tuc", "le kja m", "sao roi", "dien dai ak", "le len cmm", "so t ak", "clm dot ak", "anh kg bt duoi", "le ma em", "sua de", "tk dot nay", "le me ak", "tk oc bo", "loan phim r ak", "oc cho", "kay roi ak", "le de m", "clm ga l", "man off kg", "kay ak em", "tk oc l", "le len", "lien tuc ma", "slow kia", "oc ak", "cayy r", "muon win ak", "dot s win", "kakakk", "yeu akk may", "nhanh ma", "speed vl ayh nhi", "z ha m", "m dot ak", "m dot ma e", "tk dot kakka", "🤣🤣", "slow v", "le hon de", "lofi lun", "ui ga", "cay rui ak", "lien tuc de", "yeu v ak", "manh hon di", "kg dc ak", "oc cho ak", "sua lien tuc ma", "clm tk dot", "lien tuc nao", "sao roi m", "slow v ak", "ngu ak em", "tk dot dai cho", "liec tuc de m", "Sua lien tuc", "ko dc ak", "clm slow v", "nhanh ti dc kg", "cut tay ak", "tk ngheo", "m te nan ak", "phe ak", "co gang", "sap dc r", "ti nx di m", "speed xiu nx", "sap dc r do", "ga v ak", "sao doa kaka", "m ngu ak", "m dot ro", "tk oc dai", "oc trau ak", "cmm dot the", "man ma m", "manh nun ma", "tk dot slow v", "cay r ak", "sua de m", "lofi ma m", "sua chill v", "tk ga âkkak", "le de m", "Chill z", "sua lien tuc", "m that hoc ak", "m cay ak", "le ti de", "khac nx di", "ko lau ak", "ko sua ak", "soa da", "bt sua kg", "moe may", "sao dot v", "that hoc ak m", "cuoiia kakak", "lien tuc nua de", "le me ak", "son dj m", "tk cho dien", "hang le di m", "cho dien kg son ak", "ko vui r e", "k son chan the", "sua de m", "Alo", "lien tuc ma", "clmm", "tk mo coi", "dot ak m", "anh hot nhay ma", "nhanh ti", "co ti nua m", "co nua", "sap dc roi do", "co len m", "deo dc r ak", "bat luc ak",  "ga v em", "oc c loan luan", "tk cho dien", "son di m", "bat luc ak", "moi tay r ak", "duoi ak m", "ko on r ak", "k nghi ngoi ma", "speed ma m", "k speed dc ak", "oc cho z", "slow lai r ak", "sua lien tuc di", "k rot ma", "con di", "me m", "duoi ak", "le ma m", "r x", "lai victory ak", "victory ak", "victory tk slow ak", "k cay ma", "sao v", "cay ak m", "speed di", "dot ak m", "thg phe", "le lun", "oc cak", "sua dei", "kakâk", "le kg m", "tk dot", "cay r ak", "bat luc ak", "duoi r ak", "son dei", "tk ba do", "chay kg", "son le dei", "con cho", "cho dien cay", "ba m ngu", "clm rot ak", "lien tuc dei", "bo m speed", "speed ma", "kg on r ak", "oc lz ak", "tk ngu", "s duoi r", "nhay ngu ak", "nhay keo kg", "tk oc heo", "bu dai ak", "loan phim ak", "bat luc r ak", "deo laiik ak", "clm sua deii", "lienmienn akk", "chay ak", "le tay di", "suai le", "om han ak", "le m", "hap hoi ak", "thg phe", "que tay ak", "clm ga v", "le dei", "ngu ak", "kg son ak", "slow ak", "bat luc ak", "bat luc hot nhay ak", "m co hot k", "m hot j ay", "hot cut ak", "tk ga", "k speed dc", "doi hot nhay ak", "bo speed vl", "le ma may", "kg son dien a", "lej dei", "clm", "sua lofi e", "kg sua ak", "sao kg sua", "kg lien tuc ak", "rot nx ak", "sao ay nhi", "tk ga", "nhay ngu z", "sua dien loan ak", "co gang di", "co nua dei", "sao r", "bat luc ak m", "tay speed vcl", "man kg e", "man off kg m", "tk dot ngu", "oc cho ak", "cay r ak", "het son ak", "sao slow nx r", "duoi r ha", "moi tay ak", "anh uoc duoi", "anh manh vkl", "suadi em", "ot ak", "cay dien r", "kakak", "anh tay ma", "speed vl ay", "m sao lai", "m slow vc", "chat cham v", "lag ak m", "dap dt ak", "cay cmnr ak", "tk dot", "kg hoc ak", "ngu da", "sao do", "lien tuc di", "kg cham ma", "kakak", "tiep tuc de", "speed kg ays", "kg noi ak", "tk ga", "ga cay", "ot r ak", "so bo ak", "a speed vl", "keo man kg", "thg oc dai", "co nua dei", "sap dc r ay", "anh victory ak", "clm victory r", "victory r ak", "ez ak", "kaka", "lien tuc di", "sua manh", "nhanh kg", "cham ak",
"sua de", "cam a", "hang de", "s da", "sợ à m", "toc do ba", " speed dei" , "cham da ba", "phế a m", "bia a m", "sua đi m", "con ngu", "cay à ba", "m phèn ma", "choi ik m", "dg cau cuu a ba", " chậm à", "anh bá mà m", "sua de","cn mm","sao ay", "sua de","cay a","maude","nhanh de","sao doa","le de","cay a","sao ay","sua di m","cay a","djt me m","con mm","hang de em","moi tay am","duoi aak","duoi ke","clm m","cay t ak","speed m","sua de","gay a","yeu ak","met ak","phe kk","nhanh dei","ga ak","bede ak","sua de","cay ak","nhanh len","cham ak m","sao da","mau di m","sua hang kg","phe ak","sua de","nhanh de ","hang de","mau de","gay a","bede ak","dit mm","dua de","cay vl ak","sua mau de","nhanh len","nhanh kg" ,"sao da","o ke","cham da","t nhanh vvl","lien tuc dei","dua du","toc do de","sua de","le de","cay ak m","sua de m","sua chay di","con cho","ga ak cn","bia a","con cho ngu","soeed di m","dien me r","so ak","so ke","cay","chay ak","gay ke","clm m","akaka","cn mm","chill di","sua du","nhanh m","ga ak","tk cac",
]

def get_auth_tokens(cookie):
    headers = {'User-Agent': 'Mozilla/5.0', 'Cookie': cookie}
    try:
        r = requests.get("https://mbasic.facebook.com/", headers=headers, timeout=10)
    except Exception as e:
        print("Lỗi kết nối:", e)
        return None, None, None, None, None, None

    if r.status_code != 200:
        print("Không thể truy cập mbasic.facebook.com (status:", r.status_code, "). Cookie có thể không hợp lệ.")
        return None, None, None, None, None, None

    html = r.text
    c_user = None
    m = re.search(r'c_user=(\d+)', cookie)
    if m:
        c_user = m.group(1)

    fb_dtsg = None
    m2 = re.search(r'name="fb_dtsg" value="([^"]+)"', html)
    if m2:
        fb_dtsg = m2.group(1)

    if not c_user:
        m3 = re.search(r'\/profile.php\?id=(\d+)', html)
        if m3:
            c_user = m3.group(1)

    rev = "1"
    a = "1"
    req = "1b"
    jazoest = None
    m4 = re.search(r'name="jazoest" value="(\d+)"', html)
    if m4:
        jazoest = m4.group(1)

    return c_user, fb_dtsg, rev, req, a, jazoest


def fetch_user_name(uid, cookie):
    tokens = get_auth_tokens(cookie)
    if not tokens[0] or not tokens[1]:
        return None
    c_user, fb_dtsg, rev, req, a, jazoest = tokens
    form = {"ids[0]": uid, "fb_dtsg": fb_dtsg, "__a": a, "__req": req, "__rev": rev}
    headers = {'User-Agent': 'Mozilla/5.0', 'Cookie': cookie, 'Content-Type': 'application/x-www-form-urlencoded'}
    try:
        r = requests.post("https://www.facebook.com/chat/user_info/", headers=headers, data=form, timeout=10)
        txt = r.text
        if txt.startswith("for (;;);"):
            txt = txt[9:]
        data = json.loads(txt)
        if "payload" in data and "profiles" in data["payload"]:
            first = list(data["payload"]["profiles"].keys())[0]
            return data["payload"]["profiles"][first].get("name")
    except Exception:
        pass
    return None


def send_message(cookie, thread_id, tag_uid, tag_name, body):
    tokens = get_auth_tokens(cookie)
    if not tokens or not tokens[0] or not tokens[1]:
        print("Cookie không hợp lệ cho mục đích gửi tin nhắn.")
        return False
    c_user, fb_dtsg, rev, req, a, jazoest = tokens
    ts = str(int(time.time() * 1000))
    payload = {
        "thread_fbid": thread_id,
        "action_type": "ma-type:user-generated-message",
        "body": body,
        "client": "mercury",
        "author": f"fbid:{c_user}",
        "timestamp": ts,
        "offline_threading_id": ts,
        "message_id": ts,
        "source": "source:chat:web",
        "ephemeral_ttl_mode": "0",
        "__user": c_user,
        "__a": a,
        "__req": req,
        "__rev": rev,
        "fb_dtsg": fb_dtsg,
        "source_tags[0]": "source:chat",
        "profile_xmd[0][id]": tag_uid,
        "profile_xmd[0][offset]": 0,
        "profile_xmd[0][length]": len(f"@{tag_name}"),
        "profile_xmd[0][type]": "p",
    }
    headers = {
        'User-Agent': 'Mozilla/5.0',
        'Cookie': cookie,
        'Content-Type': 'application/x-www-form-urlencoded',
        'Referer': f'https://www.facebook.com/messages/t/{thread_id}'
    }
    try:
        r = requests.post("https://www.facebook.com/messaging/send/", data=payload, headers=headers, timeout=10)
        if r.status_code == 200:
            print(Fore.GREEN + f"✅ Gửi thành công: {body}")
            return True
        else:
            print("❌ Lỗi:", r.status_code)
            return False
    except Exception as e:
        print("Lỗi khi gửi:", e)
        return False


def main():
    cookie = input(Fore.YELLOW + "Nhập Cookie Facebook: " + Fore.GREEN).strip()
    thread_id = input(Fore.YELLOW + "Nhập ID Box: " + Fore.GREEN).strip()
    tag_uid = input(Fore.YELLOW + "Nhập UID cần tag: " + Fore.GREEN).strip()

    delay_input = input(Fore.YELLOW + "Nhập delay: " + Fore.GREEN).strip()
    min_delay, max_delay = 2.0, 5.0
    if delay_input:
        if "-" in delay_input:
            parts = delay_input.replace(" ", "").split("-")
            if len(parts) == 2:
                try:
                    min_delay = float(parts[0])
                    max_delay = float(parts[1])
                except:
                    pass
        else:
            try:
                v = float(delay_input)
                min_delay = max_delay = v
            except:
                pass

    if min_delay == max_delay:
        print(Fore.GREEN + f"Delay: {min_delay} giây")
    else:
        print(Fore.GREEN + f"Delay: {min_delay}-{max_delay} giây")

    lines = ngonnhay
    if not lines:
        print(Fore.RED + "⚠️ Không có nội dung để gửi.")
        sys.exit(1)

    name = fetch_user_name(tag_uid, cookie)
    if not name:
        name = "user"

    print(Fore.CYAN + "\n===BẮT ĐẦU GỬI===")
    try:
        while True:
            for msg in lines:
                body = f"{msg} *@{name}*"
                ok = send_message(cookie, thread_id, tag_uid, name, body)
                if not ok:
                    print(Fore.RED + "Gửi thất bại!")
                    time.sleep(5)
                    continue

                if min_delay == max_delay:
                    time.sleep(min_delay)
                else:
                    time.sleep(random.uniform(min_delay, max_delay))
    except KeyboardInterrupt:
        print("🛑 Stop!")


if __name__ == "__main__":
    main()
