import os
import sys
import time
import json
import hashlib
import random
import re
import requests
from datetime import datetime
from collections import defaultdict
from urllib.parse import urlparse
from termcolor import colored
import pyfiglet

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def banner():
    ascii_banner = pyfiglet.figlet_format("   BietDanh", font="slant")
    print(colored(ascii_banner, 'cyan', attrs=['bold']))
    print("=" * 60)
    print(colored("   Tool Treo Nhây Biệt Danh Messenger", 'white', attrs=['bold']))
    print("=" * 60)

def parse_cookie_string(cookie_string):
    """Parse cookie string thành dictionary."""
    cookie_dict = {}
    cookies = cookie_string.split(";")
    for cookie in cookies:
        if "=" in cookie:
            key, value = cookie.strip().split("=", 1)
            cookie_dict[key] = value
    return cookie_dict

def get_headers(url: str, customHeader: dict = {}) -> dict:
    """Tạo headers cho request."""
    headers = {
        "Accept-Encoding": "gzip, deflate",
        "Content-Type": "application/x-www-form-urlencoded",
        "Referer": "https://www.facebook.com/",
        "Host": urlparse(url).netloc,
        "Origin": "https://www.facebook.com",
        "User-Agent": "Mozilla/5.0 (Linux; Android 9; SM-G973U Build/PPR1.180610.011) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36",
        "Connection": "keep-alive",
    }
    
    for key in customHeader:
        headers[key] = customHeader[key]
    
    return headers

class Counter:
    """Simple counter class."""
    def __init__(self, initial_value=0):
        self.value = initial_value
        
    def increment(self):
        self.value += 1
        return self.value
        
    @property
    def counter(self):
        return self.value

def str_base(number, base):
    """Convert number to string with given base."""
    def digitToChar(digit):
        if digit < 10:
            return str(digit)
        return chr(ord('a') + digit - 10)
    
    if number < 0:
        return "-" + str_base(-number, base)
    (d, m) = divmod(number, base)
    if d > 0:
        return str_base(d, base) + digitToChar(m)
    return digitToChar(m)

# ===== QUẢN LÝ COOKIE VÀ KẾT NỐI =====

cookie_attempts = defaultdict(lambda: {
    'count': 0, 
    'last_reset': time.time(), 
    'banned_until': 0, 
    'permanent_ban': False
})

def handle_failed_connection(cookie_hash):
    """Xử lý khi kết nối thất bại."""
    global cookie_attempts
    
    current_time = time.time()
    
    if current_time - cookie_attempts[cookie_hash]['last_reset'] > 43200:
        cookie_attempts[cookie_hash]['count'] = 0
        cookie_attempts[cookie_hash]['last_reset'] = current_time
        cookie_attempts[cookie_hash]['banned_until'] = 0

# ===== HÀM CHÍNH CHO THAY ĐỔI BIỆT DANH =====

def change_nickname(nickname, thread_id, participant_id, dataFB):
    """Đổi biệt danh cho một thành viên trong nhóm."""
    try:
        form = {
            "nickname": nickname,
            "participant_id": str(participant_id),
            "thread_or_other_fbid": str(thread_id),
            "source": "thread_settings",
            "dpr": "1",
            "fb_dtsg": dataFB["fb_dtsg"],
            "jazoest": dataFB["jazoest"],
            "__user": str(dataFB["FacebookID"]),
            "__a": "1",
            "__req": str_base(Counter().increment(), 36),
            "__rev": dataFB.get("clientRevision", "1015919737")
        }

        headers = get_headers("https://www.facebook.com/messaging/save_thread_nickname/", customHeader={
            "Content-Type": "application/x-www-form-urlencoded"
        })

        response = requests.post(
            "https://www.facebook.com/messaging/save_thread_nickname/",
            data=form,
            headers=headers,
            cookies=parse_cookie_string(dataFB["cookieFacebook"]),
            timeout=10
        )

        if response.status_code != 200:
            raise Exception(f"HTTP Error {response.status_code}")

        content = response.text.replace('for (;;);', '')
        data = json.loads(content)

        if "error" in data:
            error_code = data.get("error")
            if error_code == 1545014:
                raise Exception("Trying to change nickname of user who isn't in thread")
            if error_code == 1357031:
                raise Exception("Thread doesn't exist or has no messages")
            raise Exception(f"API Error: {data.get('errorDescription', 'Unknown error')}")

        return True, f"✅ [{datetime.now().strftime('%H:%M:%S')}] Đã đổi biệt danh cho user {participant_id} thành {nickname} trong box {thread_id}"
    except Exception as e:
        return False, f"❌ [{datetime.now().strftime('%H:%M:%S')}] Lỗi khi đổi biệt danh cho user {participant_id}: {str(e)}"

def get_thread_info_graphql(thread_id, dataFB):
    """Lấy danh sách thành viên trong một nhóm chat."""
    try:
        form = {
            "queries": json.dumps({
                "o0": {
                    "doc_id": "3449967031715030",
                    "query_params": {
                        "id": str(thread_id),
                        "message_limit": 0,
                        "load_messages": False,
                        "load_read_receipts": False,
                        "before": None
                    }
                }
            }, separators=(",", ":")),
            "batch_name": "MessengerGraphQLThreadFetcher",
            "fb_dtsg": dataFB["fb_dtsg"],
            "jazoest": dataFB["jazoest"],
            "__user": str(dataFB["FacebookID"]),
            "__a": "1",
            "__req": str_base(Counter().increment(), 36),
            "__rev": dataFB.get("clientRevision", "1015919737")
        }

        headers = get_headers("https://www.facebook.com/api/graphqlbatch/", customHeader={
            "Content-Type": "application/x-www-form-urlencoded"
        })

        response = requests.post(
            "https://www.facebook.com/api/graphqlbatch/",
            data=form,
            headers=headers,
            cookies=parse_cookie_string(dataFB["cookieFacebook"]),
            timeout=10
        )

        if response.status_code != 200:
            raise Exception(f"HTTP Error {response.status_code}")

        content = response.text.replace('for (;;);', '')
        response_parts = content.split("\n")
        if not response_parts or not response_parts[0].strip():
            raise Exception("Empty response from API")

        data = json.loads(response_parts[0])

        if "error" in data:
            raise Exception(f"API Error: {data.get('errorDescription', 'Unknown error')}")

        if data.get("error_results", 0) != 0:
            raise Exception("Error results in response")

        message_thread = data["o0"]["data"]["message_thread"]
        thread_id = (message_thread["thread_key"]["thread_fbid"] 
                     if message_thread["thread_key"].get("thread_fbid") 
                     else message_thread["thread_key"]["other_user_id"])

        participant_ids = [edge["node"]["messaging_actor"]["id"] 
                          for edge in message_thread["all_participants"]["edges"]]

        return True, participant_ids, f"✅ [{datetime.now().strftime('%H:%M:%S')}] Lấy được {len(participant_ids)} thành viên trong box {thread_id}"
    except Exception as e:
        return False, [], f"❌ [{datetime.now().strftime('%H:%M:%S')}] Lỗi khi lấy thông tin box {thread_id}: {str(e)}"

class Name:
    def __init__(self, cookie):
        self.cookie = cookie
        self.user_id = self.id_user()
        self.fb_dtsg = None
        self.jazoest = None
        self.rev = None
        self.init_params()

    def id_user(self):
        """Lấy user ID từ cookie."""
        try:
            match = re.search(r"c_user=(\d+)", self.cookie)
            if not match:
                raise Exception("Cookie không hợp lệ")
            return match.group(1)
        except Exception as e:
            raise Exception(f"Lỗi khi lấy user_id: {str(e)}")

    def init_params(self):
        """Khởi tạo các tham số cần thiết từ Facebook."""
        headers = {
            'Cookie': self.cookie,
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1'
        }
        urls = [
            'https://www.facebook.com',
            'https://mbasic.facebook.com',
            'https://m.facebook.com'
        ]

        for url in urls:
            try:
                response = requests.get(url, headers=headers, timeout=10)

                if response.status_code != 200:
                    continue

                fb_dtsg_patterns = [
                    r'"token":"(.*?)"',
                    r'name="fb_dtsg" value="(.*?)"',
                    r'"fb_dtsg":"(.*?)"',
                    r'fb_dtsg=([^&"]+)'
                ]
                jazoest_pattern = r'name="jazoest" value="(\d+)"'
                rev_pattern = r'"__rev":"(\d+)"'

                fb_dtsg = None
                for pattern in fb_dtsg_patterns:
                    match = re.search(pattern, response.text)
                    if match:
                        fb_dtsg = match.group(1)
                        break

                jazoest_match = re.search(jazoest_pattern, response.text)
                rev_match = re.search(rev_pattern, response.text)

                if fb_dtsg:
                    self.fb_dtsg = fb_dtsg
                    self.jazoest = jazoest_match.group(1) if jazoest_match else "22036"
                    self.rev = rev_match.group(1) if rev_match else "1015919737"
                    return
            except Exception as e:
                continue

        raise Exception("Không thể lấy được fb_dtsg từ bất kỳ URL nào")

# ===== HÀM ĐỌC FILE =====

def read_nicknames_from_file(file_path):
    """Đọc danh sách biệt danh từ file TXT, mỗi dòng một biệt danh."""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            nicknames = [line.strip() for line in f if line.strip()]
        if not nicknames:
            raise ValueError("File biệt danh rỗng hoặc không có biệt danh hợp lệ.")
        return nicknames
    except FileNotFoundError:
        raise FileNotFoundError(f"File không tồn tại: {file_path}")
    except Exception as e:
        raise Exception(f"Lỗi khi đọc file biệt danh: {str(e)}")

# ===== HÀM CHÍNH: THAY ĐỔI BIỆT DANH VÒNG LẶP VÔ HẠN =====

def change_nicknames_all_members_infinite(cookies, thread_ids, delay, nickname_file):
    """Thay đổi biệt danh cho tất cả thành viên trong nhóm với vòng lặp vô hạn."""
    
    # Đọc danh sách biệt danh từ file
    try:
        nicknames = read_nicknames_from_file(nickname_file)
        print(colored(f"\n[+] Đã đọc {len(nicknames)} biệt danh từ file: {nickname_file}", 'green'))
    except Exception as e:
        print(colored(f"[!] Lỗi khi đọc file biệt danh: {str(e)}", 'red'))
        return False
    
    nickname_index = 0
    
    while True:  # Vòng lặp vô hạn chính
        for cookie in cookies:
            cookie_hash = hashlib.md5(cookie.encode()).hexdigest()
            
            if cookie_attempts[cookie_hash]['permanent_ban']:
                print(colored(f"[!] Cookie {cookie_hash[:10]}... Đã Bị Ngưng Hoạt Động Vĩnh Viễn", 'red'))
                continue
                
            current_time = time.time()
            if current_time < cookie_attempts[cookie_hash]['banned_until']:
                remaining = cookie_attempts[cookie_hash]['banned_until'] - current_time
                print(colored(f"[!] Cookie {cookie_hash[:10]}... Bị Tạm Khóa, Còn {remaining/3600:.1f} Giờ", 'yellow'))
                continue

            try:
                # Tạo đối tượng minhloi
                fb = minhloi(cookie)
                
                for thread_id in thread_ids:
                    print("\n" + colored("=" * 60, 'cyan'))
                    print(colored(f"[*] Bắt Đầu Xử Lý Cho Box: {thread_id}", 'cyan', attrs=['bold']))
                    print(colored(f"[*] Cookie: {cookie_hash[:10]}...", 'cyan'))
                    print(colored(f"[*] User ID: {fb.user_id}", 'cyan'))
                    print(colored("=" * 60, 'cyan'))
                    
                    try:
                        # Tạo dataFB từ thông tin cookie
                        dataFB = {
                            "FacebookID": fb.user_id,
                            "fb_dtsg": fb.fb_dtsg,
                            "clientRevision": fb.rev,
                            "jazoest": fb.jazoest,
                            "cookieFacebook": cookie
                        }
                        
                        # Lấy danh sách thành viên trong nhóm
                        success, participant_ids, log = get_thread_info_graphql(thread_id, dataFB)
                        if not success:
                            print(colored(f"[!] Không thể lấy danh sách thành viên cho box {thread_id}", 'red'))
                            continue
                        
                        print(colored(f"[+] Đã lấy được {len(participant_ids)} thành viên trong box {thread_id}", 'green'))
                        
                        # Chọn biệt danh từ danh sách
                        nickname = nicknames[nickname_index % len(nicknames)]
                        nickname_index += 1
                        
                        print(colored(f"[*] Sử dụng biệt danh: {nickname}", 'yellow', attrs=['bold']))
                        print(colored(f"[*] Bắt đầu đổi biệt danh cho {len(participant_ids)} thành viên...", 'yellow'))
                        
                        # Đổi biệt danh cho từng thành viên
                        success_count = 0
                        fail_count = 0
                        
                        for i, participant_id in enumerate(participant_ids, 1):
                            success, log = change_nickname(nickname, thread_id, participant_id, dataFB)
                            if success:
                                success_count += 1
                                print(colored(f"[{i}/{len(participant_ids)}] {log}", 'green'))
                            else:
                                fail_count += 1
                                print(colored(f"[{i}/{len(participant_ids)}] {log}", 'red'))
                            time.sleep(delay)
                        
                        print(colored(f"\n[✓] Hoàn tất đổi biệt danh cho box {thread_id}", 'green', attrs=['bold']))
                        print(colored(f"   - Thành công: {success_count}/{len(participant_ids)}", 'green'))
                        print(colored(f"   - Thất bại: {fail_count}/{len(participant_ids)}", 'red'))
                        print(colored(f"   - Biệt danh tiếp theo: {nicknames[nickname_index % len(nicknames)]}", 'yellow'))
                        
                    except KeyboardInterrupt:
                        print(colored(f"\n\n[*] Dừng xử lý cho box: {thread_id}", 'yellow'))
                        return True
                    except Exception as e:
                        print(colored(f"[!] Lỗi khi xử lý box {thread_id}: {str(e)}", 'red'))
                        time.sleep(5)  # Chờ 5 giây trước khi thử lại

            except Exception as e:
                print(colored(f"[!] Lỗi trong luồng xử lý với cookie {cookie_hash[:10]}: {e}", 'red'))
                handle_failed_connection(cookie_hash)
                continue

        print(colored(f"\n[✓] Đã hoàn thành một vòng cho tất cả cookie và box", 'green', attrs=['bold']))
        print(colored(f"[*] Bắt đầu vòng tiếp theo sau {delay} giây...", 'yellow'))
        time.sleep(delay)

    return True

# ===== HÀM CHÍNH CHƯƠNG TRÌNH =====

def treo_beo():
    """Hàm chính để chạy chương trình thay đổi biệt danh."""
    try:
        clear()
        banner()
        
        # Nhập danh sách ID Box
        id_list = []
        stt = 1
        while True:
            idbox = input(colored(f"Nhập ID Box {stt} (Ấn 'enter' để dừng nhập): ", 'yellow', attrs=['bold'])).strip()
            if idbox.lower() in ['', 'enter']:
                if id_list:
                    print(colored('\nĐã lưu ID Box:', 'green'))
                    for id_ in id_list:
                        print(f'  {id_}')
                else:
                    print(colored('Không có ID Box nào được nhập', 'red'))
                break
            if idbox.isdigit():
                id_list.append(idbox)
                stt += 1
            else:
                print(colored('ID Box phải là số, vui lòng nhập lại!', 'red'))
        
        if not id_list:
            print(colored('Vui lòng nhập ít nhất một ID Box!', 'red'))
            return

        # Nhập danh sách cookie
        cookie_list = []
        stt = 1
        while True:
            ck = input(colored(f"Nhập cookie {stt} (Ấn 'enter' để dừng nhập): ", 'yellow', attrs=['bold'])).strip()
            if ck.lower() in ['', 'enter']:
                if cookie_list:
                    print(colored('\nĐã lưu cookie:', 'green'))
                    for i, c in enumerate(cookie_list, 1):
                        print(f'  Cookie {i}: {c[:25]}...')
                else:
                    print(colored('Không có cookie nào được nhập', 'red'))
                break
            if 'c_user=' in ck and 'xs=' in ck:
                cookie_list.append(ck)
                stt += 1
            else:
                print(colored('Cookie không hợp lệ! Phải chứa c_user và xs', 'red'))
        
        if not cookie_list:
            print(colored('Vui lòng nhập ít nhất một cookie!', 'red'))
            return

        # Nhập file biệt danh
        while True:
            nickname_file = input(colored("Nhập đường dẫn file chứa biệt danh (.txt): ", 'yellow', attrs=['bold'])).strip()
            if nickname_file.lower() in ['', 'enter']:
                print(colored('Vui lòng nhập đường dẫn file!', 'red'))
                continue
            if os.path.isfile(nickname_file) and nickname_file.endswith('.txt'):
                break
            else:
                print(colored('File không tồn tại hoặc không phải file .txt!', 'red'))
        
        # Nhập delay
        while True:
            delay_input = input(colored('Nhập delay giữa các lần đổi (giây): ', 'yellow', attrs=['bold'])).strip()
            try:
                delay = float(delay_input)
                if delay >= 0:
                    break
                else:
                    print(colored('Delay phải là số dương!', 'red'))
            except ValueError:
                print(colored('Vui lòng nhập số hợp lệ!', 'red'))

        # Hiển thị thông tin cấu hình
        print("\n" + colored("=" * 60, 'cyan'))
        print(colored("[THÔNG TIN CẤU HÌNH]", 'white', attrs=['bold']))
        print(colored("=" * 60, 'cyan'))
        print(colored(f"Tổng số ID Box: {len(id_list)}", 'white'))
        for i, id_ in enumerate(id_list, 1):
            print(f"  Box {i}: {id_}")
        print(colored(f"Tổng số cookie: {len(cookie_list)}", 'white'))
        print(colored(f"File biệt danh: {nickname_file}", 'white'))
        print(colored(f"Delay: {delay} giây", 'white'))
        print(colored("Chế độ: Vòng lặp vô hạn", 'white'))
        print(colored("=" * 60, 'cyan'))
        
        # Xác nhận chạy
        confirm = input(colored("\n[?] Bắt đầu chạy chương trình? (y/n): ", 'yellow', attrs=['bold'])).strip().lower()
        if confirm != 'y':
            print(colored("[*] Hủy chạy chương trình.", 'yellow'))
            return
        
        print(colored("\n[+] Bắt đầu chạy chương trình...", 'green', attrs=['bold']))
        print(colored("[!] Nhấn Ctrl+C để dừng chương trình", 'yellow'))
        
        # Chạy chương trình
        change_nicknames_all_members_infinite(cookie_list, id_list, delay, nickname_file)
        
    except KeyboardInterrupt:
        print(colored("\n\n[*] Đã dừng chương trình.", 'yellow'))
    except Exception as e:
        print(colored(f"[!] Lỗi: {str(e)}", 'red'))

if __name__ == "__main__":
    treo_beo()