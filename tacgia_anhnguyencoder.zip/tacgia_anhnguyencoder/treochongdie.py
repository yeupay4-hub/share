import multiprocessing
import requests
import os
import re
import json
import time
import random
import pyfiglet
from termcolor import colored

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def banner():
    ascii_banner = pyfiglet.figlet_format("   Cte Vcl", font="slant")
    print(colored(ascii_banner, 'cyan', attrs=['bold']))
    print("=" * 60)
    print(colored("       Tool Treo Ngon Mess Chống Block By Cte Vcl", 'white', attrs=['bold']))
    print("=" * 60)

def get_uid(cookie):
    try:
        return re.search(r'c_user=(\d+)', cookie).group(1)
    except:
        return '0'

def check_live(cookie):
    try:
        if 'c_user=' not in cookie:
            return {"status": "failed", "msg": "Cookie không chứa user_id"}
        
        user_id = get_uid(cookie)
        headers = {
            'authority': 'm.facebook.com',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'accept-language': 'vi-VN,vi;q=0.9',
            'cache-control': 'max-age=0',
            'cookie': cookie,
            'sec-ch-ua': '"Not_A Brand";v="99", "Google Chrome";v="109", "Chromium";v="109"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-ch-ua-platform-version': '"0.1.0"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36'
        }
        profile_response = requests.get(f'https://m.facebook.com/profile.php?id={user_id}', headers=headers, timeout=30)
        name = profile_response.text.split('<title>')[1].split('<')[0].strip()
        return {
            "status": "success",
            "name": name,
            "user_id": user_id,
            "msg": "successful"
        }
    except Exception as e:
        return {"status": "failed", "msg": f"Lỗi xảy ra: {str(e)}"}

def check_account_status(cookie, user_id):
    try:
        headers = {
            'authority': 'www.facebook.com',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'accept-language': 'vi',
            'sec-ch-prefers-color-scheme': 'light',
            'sec-ch-ua': '"Chromium";v="106", "Google Chrome";v="106", "Not;A=Brand";v="99"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'none',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36',
            'Cookie': cookie
        }
        session = requests.Session()
        get = session.get('https://www.facebook.com/me', headers=headers).url
        url = 'https://www.facebook.com/' + get.split('%2F')[-2] + '/' if 'next=' in get else get
        response = session.get(url, headers=headers, params={"locale": "vi_VN"})
        data_split = response.text.split('"CurrentUserInitialData",[],{')
        json_data = '{' + data_split[1].split('},')[0] + '}'
        parsed_data = json.loads(json_data)
        id = parsed_data.get('USER_ID', '0')
        name = parsed_data.get('NAME', '')
        if id == '0' and name == '':
            return 'cookieout'
        elif '828281030927956' in response.text:
            return '956'
        elif '1501092823525282' in response.text:
            return '282'
        elif '601051028565049' in response.text:
            return 'spam'
        else:
            return {'success': 200, 'id': id, 'name': name}
    except:
        return 'error'

def load_file(file_path):
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        if not content.strip():
            raise Exception(f"File {file_path} trống!")
        return content
    except Exception as e:
        raise Exception(f"Lỗi đọc file {file_path}: {str(e)}")

class Messenger:
    def __init__(self, cookie):
        self.cookie = cookie
        self.user_id = self.get_user_id()
        self.fb_dtsg = None
        self.init_params()
        self.user_agents = [
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36",
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36"
        ]

    def get_user_id(self):
        try:
            return re.search(r"c_user=(\d+)", self.cookie).group(1)
        except:
            raise Exception("Cookie không hợp lệ")

    def init_params(self):
        headers = {
            'Cookie': self.cookie,
            'User-Agent': 'Mozilla/5.0'
        }
        try:
            for url in ['https://www.facebook.com', 'https://mbasic.facebook.com', 'https://m.facebook.com']:
                response = requests.get(url, headers=headers)
                match = re.search(r'name="fb_dtsg" value="(.*?)"', response.text)
                if match:
                    self.fb_dtsg = match.group(1)
                    return
            raise Exception("Không tìm thấy fb_dtsg")
        except Exception as e:
            raise Exception(f"Lỗi khởi tạo: {str(e)}")

    def send_message(self, recipient_id, message):
        timestamp = int(time.time() * 1000)
        data = {
            'fb_dtsg': self.fb_dtsg,
            '__user': self.user_id,
            'body': message,
            'action_type': 'ma-type:user-generated-message',
            'timestamp': timestamp,
            'offline_threading_id': str(timestamp),
            'message_id': str(timestamp),
            'thread_fbid': recipient_id,
            'source': 'source:chat:web',
            'client': 'mercury'
        }
        headers = {
            'Cookie': self.cookie,
            'User-Agent': 'Mozilla/5.0',
            'Content-Type': 'application/x-www-form-urlencoded'
        }
        try:
            response = requests.post('https://www.facebook.com/messaging/send/', data=data, headers=headers)
            return response.status_code == 200
        except:
            return False

def start_spam(cookie, account_name, user_id, thread_ids, thread_names, message_text, delay_range=(20, 30)):
    try:
        messenger = Messenger(cookie)
        while True:
            status = check_account_status(cookie, user_id)
            if status == '956':
                print(f"Tài khoản {account_name} bị checkpoint 956!")
                break
            elif status == '282':
                print(f"Tài khoản {account_name} bị checkpoint 282!")
                break
            elif status == 'spam':
                print(f"Tài khoản {account_name} bị ăn spam tự động!")
                break
            elif status == 'cookieout' or status == 'error':
                print(f"Tài khoản {account_name} cookie không hợp lệ hoặc lỗi!")
                break

            for thread_id, thread_name in zip(thread_ids, thread_names):
                success = messenger.send_message(thread_id, message_text)
                status_msg = "Thành Công" if success else "Thất Bại"
                print(f"User: {account_name} treo ngôn vào nhóm {thread_name} - {status_msg}")
                delay = random.randint(delay_range[0], delay_range[1])  # Random delay
                print(f"Delay: {delay} giây")
                time.sleep(delay)
    except Exception as e:
        print(f"Lỗi tài khoản {account_name}: {str(e)}")
        return

def start_multiple_accounts():
    clear()
    banner()

    print("=" * 60)
    print("NHẬP ID BOX")
    print("=" * 60)
    
    id_list = []
    while True:
        idbox = input("Nhập ID Box (Enter để dừng nhập): ").strip()
        if idbox == '':
            if id_list:
                print("\nĐã lưu ID Box:")
                for idx, id_ in enumerate(id_list, 1):
                    print(f"  {idx}. {id_}")
            else:
                print("Không có ID Box nào được nhập!")
            break
        if idbox.isdigit():
            id_list.append(idbox)
        else:
            print("ID Box phải là số!")
    
    if not id_list:
        print("Không có ID Box nào để gửi tin. Thoát chương trình.")
        return
    
    print("\n" + "=" * 60)
    print("NHẬP DANH SÁCH COOKIE")
    print("=" * 60)
    
    cookie_list = []
    account_info_list = []
    while True:
        cookie = input("Nhập cookie (Enter để dừng nhập): ").strip()
        if cookie == '':
            if cookie_list:
                print("\nĐã lưu cookie:")
                for idx, ck in enumerate(cookie_list, 1):
                    print(f"  {idx}. {ck[:50]}...")
            else:
                print("Không có cookie nào được nhập!")
            break
        if 'c_user=' in cookie and 'xs=' in cookie:
            cookie_list.append(cookie)
            # Kiểm tra cookie sống
            cl = check_live(cookie)
            if cl["status"] == "success":
                account_info_list.append({
                    "name": cl["name"],
                    "user_id": cl["user_id"],
                    "cookie": cookie
                })
                print(f"  ✓ {cl['name']} (ID: {cl['user_id']})")
            else:
                print(f"  ✗ Cookie không hợp lệ: {cl['msg']}")
        else:
            print("Cookie không hợp lệ (thiếu c_user hoặc xs)!")
    
    if not cookie_list:
        print("Không có cookie hợp lệ. Thoát chương trình.")
        return
    
    # NHẬP FILE CHỨA NỘI DUNG
    print("\n" + "=" * 60)
    print("NHẬP FILE NỘI DUNG")
    print("=" * 60)
    
    file_list = []
    while True:
        file_path = input("Nhập đường dẫn file .txt chứa nội dung (Enter để dừng): ").strip()
        if file_path == '':
            if file_list:
                print("\nĐã lưu file:")
                for idx, f in enumerate(file_list, 1):
                    print(f"  {idx}. {f}")
            else:
                print("Không có file nào được nhập!")
            break
        if file_path.endswith('.txt'):
            try:
                # Kiểm tra file có tồn tại và đọc được không
                content = load_file(file_path)
                file_list.append(file_path)
                print(f"  ✓ Đã tải file: {file_path}")
            except Exception as e:
                print(f"  ✗ Lỗi đọc file: {e}")
        else:
            print("File phải có đuôi .txt!")
    
    if not file_list:
        print("Không có file hợp lệ. Thoát chương trình.")
        return
    
    # NHẬP DELAY
    print("\n" + "=" * 60)
    print("NHẬP THÔNG SỐ DELAY")
    print("=" * 60)
    
    try:
        print("Delay Chậm 20-30 giây")
        delay_range = (20, 30)
    except Exception as e:
        print("Lỗi delay:", e)
        return
    
    print("\n" + "=" * 60)
    print("KHỞI ĐỘNG TREO NGÔN")
    print("=" * 60)
    
    processes = []
    
    for acc in account_info_list:
        print(f"\nKhởi động tài khoản: {acc['name']}...")
        

        all_messages = []
        for file_path in file_list:
            try:
                message_text = load_file(file_path)
                all_messages.append(message_text)
            except Exception as e:
                print(f"  ✗ Lỗi đọc file {file_path}: {e}")
                continue
        
        if not all_messages:
            print(f"  ✗ Không có nội dung nào để gửi từ tài khoản {acc['name']}")
            continue
        
        # Kết hợp tất cả nội dung từ các file
        combined_message = "\n".join(all_messages)
        
        p = multiprocessing.Process(
            target=start_spam,
            args=(acc['cookie'], acc['name'], acc['user_id'], id_list, id_list, combined_message, delay_range)
        )
        processes.append(p)
        p.start()
        time.sleep(1)
    
    if not processes:
        print("Không có tài khoản nào được khởi động. Thoát chương trình.")
        return
    
    print("\n" + "=" * 60)
    print("✅ TẤT CẢ ACCOUNT ĐÃ KHỞI ĐỘNG THÀNH CÔNG")
    print("Nhấn Ctrl+C để dừng.")
    print("=" * 60)
    
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n\n👋 Đã dừng tool. Chào tạm biệt!")
        for p in processes:
            p.terminate()
        os._exit(0)

class TreoChongDieMessenger:
    def __init__(self, cookie: str):
        self.cookie = cookie
        self.user_id = get_uid(cookie)
        self.messenger = Messenger(cookie)
        self.running = True

    def check_status(self):
        return check_account_status(self.cookie, self.user_id)

    def send(self, box_id: str, message: str):
        return self.messenger.send_message(box_id, message)

    def stop(self):
        self.running = False

if __name__ == "__main__":
    start_multiple_accounts()